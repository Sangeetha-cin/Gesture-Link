<?php
session_start();
include("config.php");

// SECURITY
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit;
}
// USER DATA
$user = $_SESSION['fullname'] ?? 'User';
$userId = $_SESSION['id'] ?? null;

date_default_timezone_set("Asia/Kolkata");

// ================================
// FETCH TODAY'S SESSION
// ================================
$session = null;

if ($userId) {
    $sql = "SELECT * FROM applications 
            WHERE user_id = ? 
              AND assigned_status = 1
              AND session_date = CURDATE()
            ORDER BY session_time ASC
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $session = $result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>User Dashboard – Gesture Link</title>

<!-- GOOGLE FONT -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
/* ===== YOUR FULL STYLE (UNCHANGED) ===== */
*{margin:0;padding:0;box-sizing:border-box;font-family:"Poppins", sans-serif;}
body{background:url("assets/userbg.webp") no-repeat center center fixed;background-size:cover;position:relative;color:white;min-height:100vh;}
body::before{content:"";position:fixed;inset:0;background:rgba(0,0,50,0.6);z-index:-1;}
nav{width:100%;background:rgba(9,44,79,0.8);padding:15px 40px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 0 15px rgba(4,35,57,0.4);position:sticky;top:0;z-index:10;backdrop-filter:blur(6px);border-radius:0 0 15px 15px;}
nav .logo{font-size:26px;font-weight:700;letter-spacing:1px;color:white;}
nav ul{display:flex;list-style:none;gap:30px;}
nav ul li a{color:white;font-size:18px;font-weight:500;text-decoration:none;padding:8px 15px;border-radius:8px;transition:0.3s;}
nav ul li a:hover{background:#0059c9;box-shadow:0 0 10px rgba(4,35,58,0.5);}
.hero{text-align:center;padding:120px 20px;background:rgba(0,0,0,0.3);margin:20px auto;max-width:90%;border-radius:20px;box-shadow:0 0 25px rgba(9,41,63,0.4);backdrop-filter:blur(8px);}
.hero h1{font-size:48px;color:#aee4ff;text-shadow:0 0 15px rgba(222,225,230,0.6);}
.hero p{font-size:18px;margin-top:15px;color:#d7f1ff;}
.container{width:90%;max-width:1200px;margin:50px auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:25px;}
.card{background:rgba(255,255,255,0.08);padding:25px;border-radius:15px;text-align:center;box-shadow:0 0 18px rgba(0,120,255,0.3);backdrop-filter:blur(6px);transition:0.3s;}
.card:hover{transform:translateY(-5px);box-shadow:0 0 25px rgba(0,150,255,0.5);}
.card h3{font-size:22px;color:#7fd0ff;margin-bottom:10px;}
.card p{color:#cfeeff;font-size:15px;}
 /* HORIZONTAL SCROLL SLIDES */
    .horizontal-section{
        width:90%;
        max-width:1200px;
        margin:70px auto;
        overflow-x:auto;
        padding-bottom:10px;
    }

    .horizontal-section h2{
        font-size:28px;
        color:#aee4ff;
        margin-bottom:20px;
        text-shadow:0 0 10px rgba(0,120,255,0.6);
        text-align:center;
    }

    .horizontal-scroll{
        display:flex;
        gap:20px;
        scroll-behavior:smooth;
        padding-bottom:10px;
    }

    .horizontal-scroll::-webkit-scrollbar{
        height:8px;
    }

    .horizontal-scroll::-webkit-scrollbar-thumb{
        background:#00bfff;
        border-radius:4px;
    }

    .horizontal-scroll::-webkit-scrollbar-track{
        background: rgba(255,255,255,0.1);
    }

    .slide-card{
        flex:0 0 300px;
        background: rgba(0,0,0,0.4);
        border-radius:15px;
        padding:20px;
        box-shadow:0 0 20px rgba(0,150,255,0.4);
        backdrop-filter:blur(6px);
        transition:0.3s;
        color:#dff6ff;
    }

    .slide-card h3{
        font-size:20px;
        color:#00e0ff;
        margin-bottom:10px;
    }

    .slide-card p{
        font-size:14px;
        line-height:1.5;
    }

    .slide-card:hover{
        transform:scale(1.05);
        box-shadow:0 0 30px rgba(0,180,255,0.6);
    }

    /* STEP BOXES SECTION */
    .steps-section{
        background:#e6f2ff;
        color:#021a33;
        padding:80px 20px;
    }

    .steps-container{
        max-width:1200px;
        margin:0 auto;
        text-align:center;
    }

    .steps-container h2{
        font-size:32px;
        margin-bottom:50px;
        color:#003f7f;
        letter-spacing:1px;
    }

    .steps-grid{
        display:grid;
        grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));
        gap:30px;
    }

    .step-box{
        background:white;
        border-radius:15px;
        padding:30px 20px;
        box-shadow:0 5px 25px rgba(0,0,0,0.1);
        transition:0.3s;
        text-align:center;
    }

    .step-box:hover{
        transform:translateY(-5px);
        box-shadow:0 10px 30px rgba(0,0,0,0.15);
    }

    .step-number{
        background:#0073e6;
        color:white;
        font-size:24px;
        font-weight:700;
        width:50px;
        height:50px;
        line-height:50px;
        border-radius:50%;
        margin:0 auto 15px auto;
    }

    .step-box h3{
        font-size:20px;
        color:#003f7f;
        margin-bottom:10px;
    }

    .step-box p{
        font-size:15px;
        color:#333;
        line-height:1.5;
    }

    /* WHITE FEATURE SECTION */
    .white-section{
        background:#f9f9f9;
        color:#021a33;
        padding:80px 20px;
    }

    .white-container{
        max-width:1200px;
        margin:0 auto;
        text-align:center;
    }

    .white-container h2{
        font-size:32px;
        margin-bottom:40px;
        color:#003f7f;
        letter-spacing:1px;
    }

    .white-cards{
        display:grid;
        grid-template-columns:repeat(auto-fit, minmax(250px, 1fr));
        gap:30px;
    }

    .white-card{
        background:white;
        border-radius:15px;
        padding:25px;
        box-shadow:0 5px 25px rgba(0,0,0,0.1);
        transition:0.3s;
        text-align:center;
    }

    .white-card h3{
        font-size:22px;
        color:#0073e6;
        margin-bottom:12px;
    }

    .white-card p{
        font-size:15px;
        color:#333;
    }

    .white-card:hover{
        transform:translateY(-5px);
        box-shadow:0 10px 30px rgba(0,0,0,0.15);
    }
    .video-call-section {
    display: flex;
    justify-content: center; /* centers horizontally */
    margin: 30px 0;          /* spacing above and below */
}

.video-call-section a,
.video-call-section button {
    background: #28a745;      /* green button */
    color: white;
    padding: 14px 28px;
    border-radius: 10px;
    font-size: 18px;
    font-weight: bold;
    text-decoration: none;
    border: none;
    cursor: pointer;
    transition: 0.3s;
}

.video-call-section a:hover,
.video-call-section button:hover {
    background: #218838; /* darker green on hover */
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>
<!-- NAVBAR -->
<nav>
     <div class="logo">Gesture Link</div>
    <ul>
        <li><a href="user_home.php">HOME</a></li>
        <li><a href="voice_assist.php">VOICE ASSIST</a></li>
        <li><a href="sign_chat.php">SIGN CHAT</a></li>
        <li><a href="apply_live_class.php">LIVE CLASS</a></li>
        <li><a href="feedback.php">FEEDBACK</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
        
    </ul>
</nav>

<!-- HERO -->
<div class="hero">
    <h1>Welcome, <?php echo htmlspecialchars($user); ?> 👋</h1>
    <p>Your gesture communication hub is ready.</p>
</div>

<div class="video-call-section">
<?php 
$now = time();
$userId = $_SESSION['id'];
$role   = $_SESSION['role'];

// Fetch today's next session for the current user
$sql = "SELECT * FROM applications 
        WHERE user_id = ? 
          AND assigned_status = 1
          AND session_date = CURDATE()
        ORDER BY session_time ASC
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$session = $result->fetch_assoc();

if($session): 
    $sessionStart = strtotime($session['session_date'] . ' ' . $session['session_time']);
    $callStatus = $session['call_status'] ?? '';
    $callRoom   = $session['call_room'] ?? '';
?>

    <?php if($callStatus === 'started' && !empty($callRoom)): ?>
        <a href="<?= htmlspecialchars($callRoom) ?>" target="_blank" class="btn-success">
            Join Video Call
        </a>
    <?php elseif($now < $sessionStart): ?>
        <button class="btn-secondary" disabled>
            Upcoming Call at <?= date("h:i A", $sessionStart) ?>
        </button>
    <?php else: ?>
        <button class="btn-secondary" disabled>
            Waiting for caregiver to start the call…
        </button>
    <?php endif; ?>

<?php else: ?>
    <p>No scheduled video calls for today.</p>
<?php endif; ?>
</div>


<!-- MAIN CARDS -->
<div class="container">
    <div class="card">
        <h3>Start Video Call</h3>
        <p>Connect instantly and translate gestures in real time.</p>
    </div>

    <div class="card">
        <h3>Upload Gestures</h3>
        <p>Upload gesture images or videos for recognition.</p>
    </div>

    <div class="card">
        <h3>Learn Gestures</h3>
        <p>Access tutorials, lessons and practice sessions.</p>
    </div>

    <div class="card">
        <h3>Support</h3>
        <p>Need help? Reach our support team anytime.</p>
    </div>
</div>
<!-- HORIZONTAL SCROLL SLIDES -->
<div class="horizontal-section">
    <h2>Latest Tutorials & Updates</h2>
    <div class="horizontal-scroll">
        <div class="slide-card">
            <h3>Gesture Basics</h3>
            <p>Learn fundamental gestures for daily communication quickly.</p>
        </div>

        <div class="slide-card">
            <h3>Advanced Gestures</h3>
            <p>Practice complex gestures and combinations with AI feedback.</p>
        </div>

        <div class="slide-card">
            <h3>Video Lessons</h3>
            <p>Watch interactive tutorials to improve your gesture recognition skills.</p>
        </div>

        <div class="slide-card">
            <h3>Community Spotlights</h3>
            <p>See trending gestures and updates shared by the user community.</p>
        </div>

        <div class="slide-card">
            <h3>Practice Challenges</h3>
            <p>Test your knowledge and get scores to track your progress.</p>
        </div>
    </div>
</div>

<!-- STEP BOXES SECTION -->
<section class="steps-section">
    <div class="steps-container">
        <h2>Get Started in 4 Easy Steps</h2>
        <div class="steps-grid">
            <div class="step-box">
                <div class="step-number">1</div>
                <h3>Create Your Profile</h3>
                <p>Fill in your details to personalize your learning experience.</p>
            </div>

            <div class="step-box">
                <div class="step-number">2</div>
                <h3>Upload Gestures</h3>
                <p>Upload your gesture images or videos to start recognition.</p>
            </div>

            <div class="step-box">
                <div class="step-number">3</div>
                <h3>Practice & Learn</h3>
                <p>Use tutorials, challenges, and feedback to improve your skills.</p>
            </div>

            <div class="step-box">
                <div class="step-number">4</div>
                <h3>Join Community</h3>
                <p>Connect with interpreters and learners to share knowledge.</p>
            </div>
        </div>
    </div>
</section>

<!-- WHITE FEATURE SECTION -->
<section class="white-section">
    <div class="white-container">
        <h2>Resources & Features</h2>
        <div class="white-cards">
            <div class="white-card">
                <h3>Gesture Dictionary</h3>
                <p>Browse a complete gesture-to-text dictionary for quick reference.</p>
            </div>

            <div class="white-card">
                <h3>AI Feedback</h3>
                <p>Receive real-time feedback on your gestures to improve accuracy.</p>
            </div>

            <div class="white-card">
                <h3>Tutorial Library</h3>
                <p>Access structured lessons and video tutorials for beginners and advanced learners.</p>
            </div>

            <div class="white-card">
                <h3>Community Forum</h3>
                <p>Interact with other users, ask questions, and share learning tips.</p>
            </div>
        </div>
    </div>
</section>

<!-- AUTO REFRESH -->
<script>
setInterval(() => {
    location.reload();
}, 30000);


function checkNotification(){
    fetch("check_notification.php")
    .then(response => response.text())
    .then(data => {
        if(data.trim() === "new"){
            showPopup();
        }
    });
}

function showPopup(){
    if(!document.getElementById("notifyBox")){
        let div = document.createElement("div");
        div.id = "notifyBox";
        div.innerHTML = "🔔 Interpreter sent you a new meaning!";
        div.style.position = "fixed";
        div.style.top = "20px";
        div.style.right = "20px";
        div.style.background = "#0044ff";
        div.style.color = "white";
        div.style.padding = "15px 20px";
        div.style.borderRadius = "10px";
        div.style.boxShadow = "0 5px 15px rgba(0,0,0,0.3)";
        div.style.zIndex = "9999";
        document.body.appendChild(div);

        setTimeout(() => {
            div.remove();
        }, 5000);
    }
}

// Check every 3 seconds
setInterval(checkNotification, 3000);
</script>

</body>
</html>