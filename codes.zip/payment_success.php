<?php
include("config.php");

$method = $_GET['method'];
$student_id = 1; // replace with session user id

$transaction_id = "TXN" . rand(100000,999999);

$sql = "INSERT INTO payments (student_id, payment_method, transaction_id)
        VALUES ('$student_id', '$method', '$transaction_id')";

mysqli_query($conn, $sql);

echo "<h2>Payment Successful</h2>";
echo "Transaction ID: " . $transaction_id;
?>