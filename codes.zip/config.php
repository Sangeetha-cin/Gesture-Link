<?php
$conn = mysqli_connect("localhost", "root", "", "gesturelink");

if(!$conn){
    die("Database connection failed: " . mysqli_connect_error());
}
?>
