<?php
session_start();
include 'config.php'; // your DB connection file

// Only admin can access
if(!isset($_SESSION['role']) || $_SESSION['role'] != 'admin'){
    header("Location: login.php");
    exit();
}

// Handle log out
if(isset($_GET['logout'])){
    session_destroy();
    header("Location: index.php");
    exit();
}

// Fetch counts for dashboard cards (compatible with older PHP versions)
$row = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='user'")->fetch_assoc();
$total_users = $row['count'];

$row = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='learner'")->fetch_assoc();
$total_learners = $row['count'];

$row = $conn->query("SELECT COUNT(*) as count FROM users WHERE role='interpreter'")->fetch_assoc();
$total_interpreters = $row['count'];

?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta charset="UTF-8">
    <title>Admin Dashboard – Gesture Link</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Poppins', sans-serif; }

        body { 
            background: #f0f2f5;
        }

      /* NAVBAR STYLES */
nav {
    width: 100%;
    background: rgba(6, 20, 41, 0.95);
    color: white;
    padding: 15px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: fixed;
    top: 0;
    left: 0;
    z-index: 100;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-family: 'Poppins', sans-serif;
}

nav .logo {
    font-size: 28px;
    font-weight: 700;
    letter-spacing: 1px;
}

nav ul {
    list-style: none;
    display: flex;
    align-items: center;
    margin: 0;
    padding: 0;
}

nav ul li {
    position: relative;  /* Required for dropdown positioning */
    margin-left: 25px;
}

nav ul li a {
    color: white;
    text-decoration: none;
    font-weight: 500;
    transition: 0.3s;
    padding: 8px 12px;
    border-radius: 5px;
    display: inline-block;
}

nav ul li a:hover {
    color: #04183a;
    background: rgba(255,255,255,0.1);
}

/* DROPDOWN MENU */
nav ul li.dropdown {
    cursor: pointer;
}

nav ul li .dropdown-menu {
    display: none;
    position: absolute;
    top: 100%;  /* Below parent */
    left: 0;
    background: rgba(255, 255, 255, 0.95);
    min-width: 220px;
    max-height: 220px;
    overflow-y: auto;
    border-radius: 8px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.3);
    z-index: 200;
    padding: 5px 0;
}

/* Dropdown Items */
nav ul li .dropdown-menu li {
    list-style: none;
    border-bottom: 1px solid #eee;
}

nav ul li .dropdown-menu li:last-child {
    border-bottom: none;
}

nav ul li .dropdown-menu a {
    color: #04183a;
    display: block;
    padding: 12px 15px;
    font-weight: 500;
    border-radius: 5px;
    transition: 0.2s;
}

nav ul li .dropdown-menu a:hover {
    background: rgba(6, 20, 41, 0.1);
    color: #04183a;
}

/* Show dropdown on hover */
nav ul li.dropdown:hover .dropdown-menu {
    display: block;
}

/* Scrollbar for dropdown */
nav ul li .dropdown-menu::-webkit-scrollbar {
    width: 6px;
}

nav ul li .dropdown-menu::-webkit-scrollbar-thumb {
    background: rgba(6,20,41,0.7);
    border-radius: 10px;
}

nav ul li .dropdown-menu::-webkit-scrollbar-track {
    background: rgba(255,255,255,0.1);
}

/* Responsive adjustments for small screens */
@media (max-width: 900px) {
    nav {
        padding: 10px 20px;
        flex-wrap: wrap;
    }

    nav ul {
        flex-direction: column;
        width: 100%;
        display: none; /* Hidden by default, toggle via JS if needed */
    }

    nav ul li {
        margin: 10px 0;
    }

    nav ul li .dropdown-menu {
        position: relative;
        top: 0;
        left: 0;
        box-shadow: none;
        max-height: 180px;
    }

    nav ul.show {
        display: flex;
    }
}

        /* HERO SECTION */
        .hero {
            width:100%;
            height:100vh;
            background: url('assets/admin-bg.webp') no-repeat center center/cover;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            color:white;
            text-align:center;
            padding-top: 70px; /* to account for navbar */
            position: relative;
        }

        .hero::after {
            content:'';
            position:absolute;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background: rgba(0,0,0,0.5);
        }

        .hero-content {
            position: relative;
            z-index:2;
        }

        .hero h1 {
            font-size: 52px;
            text-shadow: 2px 2px 15px rgba(0,0,0,0.7);
            margin-bottom: 20px;
            animation: fadeInDown 1.5s;
        }

        .hero p {
            font-size: 22px;
            max-width:750px;
            text-shadow: 1px 1px 8px rgba(0,0,0,0.6);
            animation: fadeInUp 1.5s;
        }

        @keyframes fadeInDown {
            0% {opacity:0; transform: translateY(-50px);}
            100% {opacity:1; transform: translateY(0);}
        }
        @keyframes fadeInUp {
            0% {opacity:0; transform: translateY(50px);}
            100% {opacity:1; transform: translateY(0);}
        }

        /* DASHBOARD CARDS */
        .dashboard {
            display:flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin:50px auto;
            width:90%;
        }

        .card {
            background: linear-gradient(135deg, rgba(13,71,161,0.85), rgba(0,200,118,0.85));
            width:270px;
            height:160px;
            margin:20px;
            border-radius: 20px;
            text-align:center;
            color:white;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            box-shadow: 0 0 25px rgba(0,0,0,0.4);
            transition:0.4s;
            position: relative;
            overflow: hidden;
        }

        .card::before {
            content:'';
            position:absolute;
            top:0;
            left:-50%;
            width:200%;
            height:100%;
            background: rgba(255,255,255,0.1);
            transform: skewX(-25deg);
            transition:0.6s;
        }

        .card:hover::before {
            left:50%;
        }

        .card h2 { font-size: 38px; margin-bottom:8px; }
        .card p { font-size:18px; }

      /* ============================= */
/* PROFESSIONAL FOOTER           */
/* ============================= */

footer {
    background: #0f172a;
    color: #cbd5e1;
    padding: 50px 20px;
    text-align: center;
    font-size: 14px;
    letter-spacing: 0.5px;
}

footer span {
    display: block;
    margin-top: 10px;
    font-size: 13px;
    color: #94a3b8;
}
/* PROFESSIONAL FEATURE SECTION  */
/* ============================= */

.additional-content {
    width: 90%;
    margin: 80px auto;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 30px;
}

.additional-card {
    background: #ffffff;
    padding: 35px;
    border-radius: 18px;
    border: 1px solid #e5e7eb;
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.additional-card::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 5px;
    background: linear-gradient(90deg, #0d47a1, #1565c0);
}

.additional-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 18px 50px rgba(0, 0, 0, 0.08);
}

.additional-card h3 {
    font-size: 20px;
    margin-bottom: 15px;
    color: #111827;
    font-weight: 600;
}

.additional-card p {
    font-size: 15px;
    line-height: 1.7;
    color: #6b7280;
}

        /* Footer */
       /* ============================= */
/* PROFESSIONAL INFO SECTION     */
/* ============================= */

.info-section {
    width: 100%;
    padding: 100px 20px;
    background: #f8fafc;
}

.info-section h1 {
    text-align: center;
    margin-bottom: 70px;
    font-size: 34px;
    font-weight: 700;
    color: #0f172a;
}

.info-box {
    width: 75%;
    margin: 30px auto;
    padding: 40px;
    border-radius: 18px;
    background: #ffffff;
    border: 1px solid #e2e8f0;
    box-shadow: 0 15px 45px rgba(0,0,0,0.05);
    transition: 0.3s ease;
}

.info-box:hover {
    transform: translateY(-6px);
}

.info-box h2 {
    font-size: 22px;
    margin-bottom: 12px;
    color: #0d47a1;
    font-weight: 600;
}

.info-box p {
    font-size: 15px;
    color: #475569;
    line-height: 1.8;
}

    </style>
    <script src="js/smart-voice-system.js"></script>
</head>
<body>

<!-- NAVBAR -->
<nav>
    <div class="logo">Gesture Link</div>

    <ul class="nav-links">
        <li><a href="adminhome.php">HOME</a></li>

        <!-- DROPDOWN -->
        <li class="dropdown">
            <a href="#">MANAGE ▾</a>
            <ul class="dropdown-menu">
                <li><a href="view_users.php">VIEW USERS</a></li>
                <li><a href="view_learners.php">VIEW LEARNERS</a></li>
                <li><a href="view_interpreters.php">VIEW INTERPRETERS</a></li>
                <li><a href="view_caregiver.php">VIEW CAREGIVERS</a></li>
                <li><a href="view_session.php">VIEW SESSION COORDINATOR</a></li>
            </ul>
        </li>

        <li><a href="admin_view_feedback.php">FEEDBACK</a></li>
        <li><a href="?logout=true">LOG OUT</a></li>
    </ul>
</nav>

<!-- HERO SECTION -->
<section class="hero" id="hero">
    <div class="hero-content">
        <h1>Welcome, Admin!</h1>
</section>

<!-- DASHBOARD CARDS -->
<div class="dashboard">
    <div class="card">
        <h2><?= $total_users ?></h2>
        <p>Total Users</p>
    </div>
    <div class="card">
        <h2><?= $total_learners ?></h2>
        <p>Total Learners</p>
    </div>
    <div class="card">
        <h2><?= $total_interpreters ?></h2>
        <p>Total Interpreters</p>
    </div>
</div>

<!-- ADDITIONAL CONTENT BELOW CARDS -->
<div class="additional-content">
    <div class="additional-card">
        <h3>Approve Registrations</h3>
        <p>Quickly approve or reject new user, learner, or interpreter registrations to maintain the community efficiently.</p>
    </div>
    <div class="additional-card">
        <h3>Monitor User Activity</h3>
        <p>Keep track of login counts, monitor platform usage trends, and ensure active engagement of your users.</p>
    </div>
    <div class="additional-card">
        <h3>Maintain Platform Integrity</h3>
        <p>Ensure that all users have correct roles, manage access rights, and maintain a safe and organized platform.</p>
    </div>
</div>

<!-- INFO SECTION -->
<section class="info-section">
    <h1>About Admin Dashboard</h1>
    <div class="info-box">
        <h2>Manage Users</h2>
        <p>View all registered users, learners, and interpreters. Approve or reject new registrations and keep track of all active members.</p>
    </div>
    <div class="info-box">
        <h2>Monitor Usage</h2>
        <p>Track the number of times each user logs in, see trends, and ensure the platform is being used efficiently.</p>
    </div>
    <div class="info-box">
        <h2>Maintain Community</h2>
        <p>Keep the Gesture Link community safe and organized by controlling user access and maintaining role integrity.</p>
    </div>
</section>

<footer>
    &copy; <?= date('Y') ?> Gesture Link. All rights reserved.
</footer>

</body>
</html>   