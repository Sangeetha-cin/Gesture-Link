<?php
session_start();
if(!isset($_SESSION['user'])){
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>User Dashboard</title>

    <style>
        body {
            margin: 0;
            font-family: Poppins, sans-serif;
            background: #082248;
            color: white;
            text-align: center;
        }

        .box {
            background: white;
            color: #082248;
            width: 300px;
            padding: 20px;
            border-radius: 18px;
            margin: 20px auto;
            font-weight: 600;
            font-size: 20px;
            cursor: pointer;
            transition: 0.3s;
        }

        .box:hover {
            transform: scale(1.05);
        }

        a {
            text-decoration: none;
        }

        h1 {
            margin-top: 40px;
            font-size: 35px;
        }
    </style>

</head>
<body>

<h1>Welcome, <?php echo $user['fullname']; ?> 👋</h1>

<br><br>

<a href="interpreter.php"><div class="box">Interpreter Mode</div></a>
<a href="learner.php"><div class="box">Learner Mode</div></a>
<a href="profile.php"><div class="box">My Profile</div></a>
<a href="logout.php"><div class="box">Logout</div></a>

</body>
</html>
