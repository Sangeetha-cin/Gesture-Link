<?php
session_start();
include("config.php");

if (!isset($_SESSION['role']) ||
    ($_SESSION['role'] !== 'interpreter' && $_SESSION['role'] !== 'admin')) {
    header("Location: login.php");
    exit();
}

/* Save Meaning */
if (isset($_POST['save'])) {

    $id = intval($_POST['id']);
    $meaning = mysqli_real_escape_string($conn, $_POST['meaning']);

    $query = "UPDATE gestures 
              SET description='$meaning', 
                  status='approved',
                  message_status='unread'
              WHERE gesture_id=$id";

    if (mysqli_query($conn, $query)) {
        $_SESSION['message'] = "Meaning saved & gesture approved!";
    } else {
        $_SESSION['message'] = "Database update failed!";
    }

    header("Location: pending_meaning.php");
    exit();
}

/* Fetch Pending */
$result = mysqli_query($conn,"
SELECT gesture_id, filename, voice_filename, description
FROM gestures
WHERE status='pending' OR description='Pending approval'
ORDER BY gesture_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Pending Gesture Review</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Inter, sans-serif;
}

/* Background */

body{
background: linear-gradient(135deg,#f1f5ff,#e9f0ff);
min-height:100vh;
}

/* Main Container */

.overlay{
padding:50px 20px;
display:flex;
justify-content:center;
}

.container{
width:100%;
max-width:1200px;

background:white;
border-radius:28px;

padding:40px;

box-shadow:
0 20px 60px rgba(0,0,0,0.08);
}

/* Title Typography */

h2{
text-align:center;
font-size:30px;
font-weight:600;

margin-bottom:35px;

background: linear-gradient(90deg,#0f172a,#2563eb);
-webkit-background-clip:text;
-webkit-text-fill-color:transparent;
}

/* Message Box */

.message-box{
text-align:center;

padding:14px;

background:#dcfce7;
color:#166534;

border-radius:12px;

margin-bottom:25px;

font-weight:500;
}

/* Table Style */

table{
width:100%;
border-collapse:collapse;
}

th{
background: linear-gradient(135deg,#0f172a,#1e3a8a);

color:white;

padding:16px;

font-weight:500;
letter-spacing:0.5px;
}

td{
padding:20px 12px;

text-align:center;

border-bottom:1px solid #f1f5f9;
}

/* Row Hover */

tr{
transition:0.3s;
}

tr:hover{
background:#f8fafc;
}

/* Media Preview */

video, audio{
width:180px;

border-radius:16px;

box-shadow:0 8px 25px rgba(0,0,0,0.08);
}

/* Input */

input[type=text]{
width:220px;

padding:11px;

border-radius:10px;

border:1px solid #e2e8f0;

transition:0.3s;
}

input:focus{
outline:none;
border-color:#3b82f6;
box-shadow:0 0 0 3px rgba(59,130,246,0.15);
}

/* Button */

button{
background: linear-gradient(135deg,#22c55e,#16a34a);

color:white;

border:none;

padding:10px 22px;

border-radius:10px;

font-weight:600;

cursor:pointer;

transition:0.3s;
}

button:hover{
transform:translateY(-2px);
box-shadow:0 8px 20px rgba(0,0,0,0.12);
}

/* Home Button */

.home-btn{
display:block;

width:220px;

margin:40px auto 0;

text-align:center;

padding:14px;

background:#0f172a;

color:white;

text-decoration:none;

border-radius:14px;

font-weight:600;

transition:0.3s;
}

.home-btn:hover{
background:#020617;
}

/* Mobile Responsive */

@media(max-width:768px){
table{
display:block;
overflow-x:auto;
}
}

</style>

<script src="js/smart-voice-system.js"></script>

</head>

<body>

<div class="overlay">

<div class="container">

<h2>Gesture Meaning Review Dashboard</h2>

<?php
if(isset($_SESSION['message'])){
echo "<div class='message-box'>".
htmlspecialchars($_SESSION['message'])."</div>";
unset($_SESSION['message']);
}
?>

<table>

<tr>
<th>ID</th>
<th>Preview</th>
<th>Enter Meaning</th>
<th>Action</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td><?= $row['gesture_id'] ?></td>

<td>

<?php
if(!empty($row['filename'])){
$file=htmlspecialchars($row['filename']);
$ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));

if(in_array($ext,['mp4','webm','ogg'])){
echo "<video controls src='$file'></video>";
}
elseif(in_array($ext,['mp3','wav'])){
echo "<audio controls src='$file'></audio>";
}
}

if(!empty($row['voice_filename'])){
echo "<audio controls src='".htmlspecialchars($row['voice_filename'])."'></audio>";
}
?>

</td>

<td>

<form method="POST">

<input type="hidden" name="id"
value="<?= $row['gesture_id'] ?>">

<input type="text"
name="meaning"
required
placeholder="Enter meaning"
value="<?= htmlspecialchars(
($row['description'] && $row['description'] !== 'Pending approval')
? $row['description']
: ''
) ?>">

</td>

<td>
<button type="submit" name="save">Approve</button>
</form>
</td>

</tr>

<?php } ?>

</table>

<a href="interpreter_home.php" class="home-btn">⬅ Back to Home</a>

</div>
</div>

</body>
</html>