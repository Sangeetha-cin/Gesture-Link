<?php

require('vendor/autoload.php');

use Razorpay\Api\Api;

// 🔑 Replace with your Key ID & Secret
$keyId = "rzp_test_SLEbRgnOW8LP57";
$keySecret = "6i9NnEbUmigHuVcGPSU8H4Ox";

$api = new Api($keyId, $keySecret);

// Amount in paise (149 INR = 14900)
$amount = 14900;

$orderData = [
    'receipt'         => 'rcptid_' . rand(1000,9999),
    'amount'          => $amount,
    'currency'        => 'INR',
    'payment_capture' => 1
];

$order = $api->order->create($orderData);

echo json_encode($order);