<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$room = $_GET['room'] ?? '';
if(!$room) exit("Invalid room");

$role = $_SESSION['role'];   // user | learner | caregiver
?>
<!DOCTYPE html>
<html>
<head>
<title>Video Call</title>
<script src="https://meet.jit.si/external_api.js"></script>
</head>
<body style="margin:0;">

<div id="jitsi-container" style="width:100%; height:100vh;"></div>

<script>
const domain = "meet.jit.si";

const options = {
    roomName: "<?php echo htmlspecialchars($room); ?>",
    parentNode: document.querySelector('#jitsi-container'),
    configOverwrite: { prejoinPageEnabled: false }
};

const api = new JitsiMeetExternalAPI(domain, options);

api.addEventListener('videoConferenceLeft', () => {
    const role = "<?php echo $role; ?>";
    if(role === "user"){
        window.location.replace("user_home.php");
    }
    else if(role === "learner"){
        window.location.replace("learner_home.php");
    }
    else if(role === "caregiver"){
        window.location.replace("caregiver_home.php");
    }
    else{
        window.location.replace("login.php");
    }
});
</script>

</body>
</html>
