<?php
session_start();
include("config.php");

/* ROLE CHECK */
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'session') {
    header("Location: login.php");
    exit();
}

$coordinatorId = $_SESSION['id'];
$success = "";
if (isset($_SESSION['success_msg'])) {
    $success = $_SESSION['success_msg'];
    unset($_SESSION['success_msg']);
}

/* ================= ASSIGN CAREGIVER ================= */
if (isset($_POST['assign_caregiver'])) {

    $appId = (int)$_POST['application_id'];
    $caregiver_id = (int)($_POST['caregiver_id'] ?? 0);

    if ($caregiver_id <= 0) {
        $_SESSION['success_msg'] = "Please select a valid caregiver!";
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

    /* ✅ FETCH CORRECT (LATEST) APPLICATION ROW */
    $chk = mysqli_query($conn, "
        SELECT user_id, assigned_status, session_date, session_time, period, amount
        FROM applications
        WHERE id = $appId
        AND session_coordinator_id = $coordinatorId
        ORDER BY id DESC
        LIMIT 1
    ");
    $chkRow = mysqli_fetch_assoc($chk);

    if (!$chkRow || $chkRow['assigned_status'] != 1) {
        $_SESSION['success_msg'] = "Applicant not approved yet!";
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

    $learnerId   = $chkRow['user_id'];
    $sessionDate = $chkRow['session_date'];
    $sessionTime = $chkRow['session_time'];
    $period      = $chkRow['period'];
    $amount      = $chkRow['amount'];

    /* PERIOD → MINUTES */
    $periodMin = 30;
    if ($period === '45 min') $periodMin = 45;
    if ($period === '1 hour') $periodMin = 60;

    $newStart = "$sessionDate $sessionTime";
    $newEnd   = date("Y-m-d H:i:s", strtotime($newStart) + ($periodMin * 60));

    /* ✅ FIXED AVAILABILITY CHECK (DATETIME) */
    $check_cg = mysqli_query($conn, "
        SELECT id FROM sessions
        WHERE caregiver_id = $caregiver_id
        AND (
            '$newStart' < DATE_ADD(CONCAT(session_date,' ',session_time),
                INTERVAL 
                CASE 
                    WHEN period='30 min' THEN 30
                    WHEN period='45 min' THEN 45
                    WHEN period='1 hour' THEN 60
                    ELSE 60
                END MINUTE
            )
            AND
            '$newEnd' > CONCAT(session_date,' ',session_time)
        )
    ");

    if (mysqli_num_rows($check_cg) > 0) {
        $_SESSION['success_msg'] = "Selected caregiver is not available at this time!";
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

    /* ================= CREATE SESSION ================= */
    $stmt = $conn->prepare("
        INSERT INTO sessions
        (caregiver_id, learner_id, session_coordinator_id, session_date, session_time, period, amount, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $status = 'pending';
    $stmt->bind_param(
        "iiisssis",
        $caregiver_id,
        $learnerId,
        $coordinatorId,
        $sessionDate,
        $sessionTime,
        $period,
        $amount,
        $status
    );
    $stmt->execute();
    $stmt->close();

    /* ================= UPDATE APPLICATION ================= */
    $stmt2 = $conn->prepare("
        UPDATE applications 
        SET assigned_caregiver_id = ?
        WHERE id = ?
    ");
    $stmt2->bind_param("ii", $caregiver_id, $appId);
    $stmt2->execute();
    $stmt2->close();

    $_SESSION['success_msg'] = "Caregiver assigned successfully.";
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

/* ================= FETCH APPROVED APPLICATIONS ================= */
$sql = "
SELECT 
    a.id AS app_id,
    a.user_id,
    a.assigned_status,
    a.assigned_caregiver_id,
    a.created_at,
    a.session_date,
    a.session_time,
    a.period,
    u.name AS applicant_name,
    u.role AS applicant_role
FROM applications a
JOIN users u ON a.user_id = u.id
WHERE a.assigned_status >= 1
AND a.session_coordinator_id = $coordinatorId
ORDER BY a.created_at DESC
";

$result = mysqli_query($conn, $sql);
if (!$result) {
    die("SQL Error: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Caregiver – Applicant Sessions</title>
<style>
    select option.free {
    color: #27ae60;
    font-weight: bold;
}

select option.busy {
    color: #e74c3c;
    font-weight: bold;
}

body {font-family: "Segoe UI", Tahoma, sans-serif; background-color: #eef1f5; padding: 30px;}
h2 {text-align: center; color: #2c3e50; margin-bottom: 25px;}
table {width: 100%; border-collapse: collapse; background: #ffffff; box-shadow: 0 15px 35px rgba(0,0,0,0.15); border-radius: 12px; overflow: hidden;}
th {background: linear-gradient(135deg, #667eea, #764ba2); color: #ffffff; padding: 14px; font-size: 14px; text-transform: uppercase;}
td {padding: 12px; font-size: 14px; color: #333;}
tr:nth-child(even) {background-color: #f8f9fc;}
tr:hover {background-color: #eef2ff; transition: 0.3s;}
select {padding: 8px; border-radius: 6px; border: 1px solid #ccc; font-weight: 600; outline: none; min-width: 150px;}
select option.free {color: #27ae60; font-weight: bold;}
select option.busy {color: #e74c3c; font-weight: bold;}
.success-msg {background: #d1fae5; color: #065f46; padding: 12px 18px; margin-bottom: 20px; border-radius: 8px; font-weight: 600; text-align: center;}
button {margin-top: 6px; padding: 8px 14px; background: linear-gradient(135deg, #43cea2, #185a9d); border: none; border-radius: 20px; color: #fff; font-weight: bold; cursor: pointer;}
.back-btn {display:inline-block; padding:8px 14px; margin-bottom:20px; background:#667eea; color:#fff; border-radius:20px; text-decoration:none;}
</style>
<script src="js/smart-voice-system.js"></script>
</head>
<body>

<h2>Caregiver – Applicant Sessions</h2>
<a href="session_home.php" class="back-btn">← Back</a>

<?php if ($success != "") { ?>
<div class="success-msg"><?= $success; ?></div>
<?php } ?>

<table>
<tr>
<th>Applicant</th>
<th>Type</th>
<th>Class Date & Time</th>
<th>Applied On</th>
<th>Status</th>
<th>Assign Caregiver</th>
</tr>

<?php while ($row = mysqli_fetch_assoc($result)) {

    $assigned = !empty($row['assigned_caregiver_id']);
    $sessionDate = $row['session_date'];
    $sessionTime = $row['session_time'];
    $newStart = "$sessionDate $sessionTime";

    $periodMin = 30;
    if ($row['period'] == '45 min') $periodMin = 45;
    if ($row['period'] == '1 hour') $periodMin = 60;
    $newEnd = date("Y-m-d H:i:s", strtotime($newStart) + ($periodMin * 60));

    $cg = mysqli_query($conn, "
        SELECT c.id, c.name,
        IF(EXISTS(
            SELECT 1 FROM sessions s2
            WHERE s2.caregiver_id = c.id
            AND (
                '$newStart' < DATE_ADD(CONCAT(s2.session_date,' ',s2.session_time),
                    INTERVAL 
                    CASE 
                        WHEN s2.period='30 min' THEN 30
                        WHEN s2.period='45 min' THEN 45
                        WHEN s2.period='1 hour' THEN 60
                        ELSE 60
                    END MINUTE)
                AND
                '$newEnd' > CONCAT(s2.session_date,' ',s2.session_time)
            )
        ),'busy','free') AS state
        FROM users c
        WHERE c.role='caregiver'
    ");
?>

<tr>
<td><?= htmlspecialchars($row['applicant_name']); ?></td>
<td><?= ucfirst($row['applicant_role']); ?></td>
<td><?= $row['session_date'].' '.$row['session_time']; ?></td>
<td><?= $row['created_at']; ?></td>
<td><?= ($row['assigned_status']==1?'Approved':'Pending'); ?></td>
<td>
<?php if ($assigned) { ?>
<b style="color:green;">Assigned</b>
<?php } else { ?>
<form method="post">
<input type="hidden" name="application_id" value="<?= $row['app_id']; ?>">
<select name="caregiver_id" required>
<option value="">-- Select --</option>
<?php while ($c = mysqli_fetch_assoc($cg)) { ?>
<option 
    value="<?= $c['id']; ?>"
    class="<?= $c['state']; ?>"
    <?= ($c['state']=='busy') ? 'disabled' : ''; ?>
>

<?= $c['name']; ?> <?= ($c['state']=='busy')?'(Busy)':''; ?>
</option>
<?php } ?>
</select>
<button name="assign_caregiver">Assign</button>
</form>
<?php } ?>
</td>
</tr>

<?php } ?>
</table>

</body>
</html>
