<?php
session_start();
include("config.php");

// Only allow SESSION role
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'session') {
    header("Location: login.php");
    exit();
}

$coordinatorId = $_SESSION['id'];
$coordinatorName = $_SESSION['name'] ?? 'Session User';

// =========================
// HANDLE APPROVE
// =========================
if (isset($_POST['approve'])) {

    $appId = (int)$_POST['application_id'];

    // 1️⃣ Fetch the application row
    $res = mysqli_query($conn, "SELECT * FROM applications WHERE id=$appId LIMIT 1");
    $row = mysqli_fetch_assoc($res);

    $learner_id   = (int)$row['user_id'];
    $caregiver_id = (int)$row['assigned_caregiver_id'];
    $session_date = $row['session_date'];
    $session_time = $row['session_time'];
    $period       = mysqli_real_escape_string($conn, $row['period']);
    $amount       = (float)$row['amount'];

    // 2️⃣ Insert into sessions table ✅ FIX
    $insert = "
    INSERT INTO sessions 
    (
        caregiver_id,
        learner_id,
        session_date,
        session_time,
        period,
        amount,
        status,
        created_at,
        session_coordinator_id
    )
    VALUES 
    (
        $caregiver_id,
        $learner_id,
        '$session_date',
        '$session_time',
        '$period',
        $amount,
        'pending',
        NOW(),
        $coordinatorId
    )
    ";
    mysqli_query($conn, $insert);

    // 3️⃣ Mark application as approved
    mysqli_query($conn, "
        UPDATE applications 
        SET assigned_status = 1,
            session_coordinator_id = $coordinatorId
        WHERE id = $appId
    ");

    header("Location: session_op.php");
    exit();
}

// =========================
// HANDLE REJECT
// =========================
if (isset($_POST['reject'])) {

    $appId = (int)$_POST['application_id'];

    mysqli_query($conn, "
        UPDATE applications 
        SET assigned_status = -1,
            session_coordinator_id = $coordinatorId
        WHERE id = $appId
    ");

    header("Location: session_op.php");
    exit();
}

// =========================
// FETCH APPLICATIONS
// =========================
$sql = "
SELECT 
    a.id AS app_id,
    a.assigned_status,
    a.created_at,
    a.session_date,
    a.session_time,
    u.name AS applicant_name
FROM applications a
JOIN users u ON a.user_id = u.id
WHERE a.assigned_status = 0 
   OR a.session_coordinator_id = $coordinatorId
ORDER BY a.created_at DESC
";

$result = mysqli_query($conn, $sql);
if(!$result){
    die('SQL Error: '.mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Session Management – Gesture Link</title>

<style>
body {font-family:Poppins;background:#0a0a23;color:white;}
.wrapper{max-width:1100px;margin:auto;padding:30px;}
header{display:flex;justify-content:space-between;align-items:center;background:#061429;padding:20px 30px;border-radius:12px;}
.back-btn{background:#0044ff;padding:10px 20px;border-radius:25px;color:white;text-decoration:none;}
table{width:100%;margin-top:30px;border-collapse:collapse;}
th,td{padding:14px;text-align:center;}
th{background:#0044ff;}
tr:nth-child(even){background:rgba(255,255,255,0.05);}
button{padding:8px 14px;border-radius:8px;border:none;font-weight:600;}
.approve{background:#00e676;}
.reject{background:#ff3d00;color:white;}
.disabled{background:#555;color:#aaa;cursor:not-allowed;}
.status-approved{color:#00e676;}
.status-rejected{color:#ff5252;}
.status-pending{color:#ffd740;}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>
<div class="wrapper">

<header>
<h2>Welcome, <?= htmlspecialchars($coordinatorName) ?></h2>
<a href="session_home.php" class="back-btn">← Back</a>
</header>

<table>
<tr>
<th>Applicant</th>
<th>Class Date & Time</th>
<th>Applied On</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while ($row = mysqli_fetch_assoc($result)): ?>

<?php
$statusValue = (int)$row['assigned_status'];

if ($statusValue === 1) {
    $statusText  = 'Approved';
    $statusClass = 'status-approved';
}
elseif ($statusValue === -1) {
    $statusText  = 'Rejected';
    $statusClass = 'status-rejected';
}
else {
    $statusText  = 'Pending';
    $statusClass = 'status-pending';
}
?>

<tr>
<td><?= htmlspecialchars($row['applicant_name']) ?></td>
<td><?= $row['session_date'] ? $row['session_date'].' '.$row['session_time'] : '—' ?></td>
<td><?= $row['created_at'] ?></td>
<td class="<?= $statusClass ?>"><?= $statusText ?></td>
<td>
<?php if ($statusValue === 0): ?>
<form method="post" style="display:inline;">
<input type="hidden" name="application_id" value="<?= $row['app_id'] ?>">
<button class="approve" name="approve">Approve</button>
</form>

<form method="post" style="display:inline;">
<input type="hidden" name="application_id" value="<?= $row['app_id'] ?>">
<button class="reject" name="reject">Reject</button>
</form>
<?php else: ?>
<button class="disabled">Closed</button>
<?php endif; ?>
</td>
</tr>

<?php endwhile; ?>
</table>

</div>
</body>
</html>
