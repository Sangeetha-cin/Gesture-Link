<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include("config.php");

// Only Interpreter Access
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'interpreter') {
    echo "<script>alert('Please login as Interpreter first!'); window.location.href='login.php';</script>";
    exit();
}

$interpreter_id = $_SESSION['id'];
$success = $error = "";

// Detect Edit Mode
$edit_mode = false;
$editID = "";
$edit_name = "";
$edit_desc = "";
if(isset($_SESSION['success_msg'])){
    $success = $_SESSION['success_msg'];
    unset($_SESSION['success_msg']);
}

// When Edit Button Clicked → Load Data into Form
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $editID = intval($_GET['edit']);

    $edit_q = mysqli_query($conn, "SELECT gesture_name, description FROM gestures WHERE gesture_id='$editID' AND interpreter_id='$interpreter_id'");
    if (mysqli_num_rows($edit_q) > 0) {
        $data = mysqli_fetch_assoc($edit_q);
        $edit_name = $data['gesture_name'];
        $edit_desc = $data['description'];
    } else {
        $edit_mode = false;
        $error = "Gesture Not Found!";
    }
}

// Update Gesture
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update'])) {
    $id = intval($_POST['gesture_id']);
    $gesture_name = mysqli_real_escape_string($conn, $_POST['gesture_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    mysqli_query($conn, "UPDATE gestures SET gesture_name='$gesture_name', description='$description'
                         WHERE gesture_id='$id' AND interpreter_id='$interpreter_id'");
    $success = "Gesture updated successfully!";
    $edit_mode = false;
}

// Approve Pending Gestures
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['approve_pending'])) {
    $pend_id = intval($_POST['gesture_id']);
    $pend_name = mysqli_real_escape_string($conn, $_POST['gesture_name']);
    $pend_desc = mysqli_real_escape_string($conn, $_POST['description']);

    mysqli_query($conn, "UPDATE gestures SET gesture_name='$pend_name', description='$pend_desc', status='approved', interpreter_id='$interpreter_id' WHERE gesture_id='$pend_id'");
    $success = "Pending gesture approved successfully!";
}

// Handle Gesture / Voice Upload
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])) {

    $gesture_name = mysqli_real_escape_string($conn, $_POST['gesture_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    if (!empty($_FILES['gesture_file']['name'])) {

        $file_name = $_FILES['gesture_file']['name'];
        $file_tmp = $_FILES['gesture_file']['tmp_name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        // Allowed extensions include gestures, videos, and audio
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'webm', 'ogg', 'mp3', 'wav', 'json'];

        if (!in_array($file_ext, $allowed)) {
            $error = "Invalid file format!";
        } else {
            $new_name = time() . "_" . preg_replace("/[^a-zA-Z0-9\-_\.]/", "_", $file_name);

            // Decide folder based on type
            if (in_array($file_ext, ['mp4','webm','ogg','jpg','jpeg','png','gif','webp','json'])) {
                $file_path = "gestures/" . $new_name;
                if (!is_dir("gestures/")) mkdir("gestures/", 0755, true);
            } else { // mp3/wav → voice folder
                $file_path = "uploads/voice/" . $new_name;
                if (!is_dir("uploads/voice/")) mkdir("uploads/voice/", 0755, true);
            }
if (move_uploaded_file($file_tmp, $file_path)) {

mysqli_query($conn, "INSERT INTO gestures
(interpreter_id, gesture_name, description, filename, status)
VALUES ('$interpreter_id','$gesture_name','$description','$file_path','approved')");

/* Prevent Duplicate Refresh Insert */
$_SESSION['success_msg'] = "Gesture / Voice uploaded successfully!";

header("Location: upload_gestures.php");
exit();
}
            else {
                $error = "Error uploading!";
            }
        }
    } else {
        $error = "Please select a file!";
    }
}

// Delete Gesture
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    $file_q = mysqli_query($conn, "SELECT filename FROM gestures WHERE gesture_id='$id' AND interpreter_id='$interpreter_id'");
    if (mysqli_num_rows($file_q) > 0) {
        $row = mysqli_fetch_assoc($file_q);
        if (file_exists($row['filename'])) unlink($row['filename']);
        mysqli_query($conn, "DELETE FROM gestures WHERE gesture_id='$id'");
        $success = "Gesture deleted!";
    }
}

// Fetch List
$gestures = mysqli_query($conn, "SELECT * FROM gestures WHERE interpreter_id='$interpreter_id' ORDER BY gesture_id DESC");

// Fetch Pending Gestures
$pending_gestures = mysqli_query($conn, "SELECT * FROM gestures WHERE status='pending' ORDER BY uploaded_at DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Upload Gestures</title>
<style>
<?php /* KEEP YOUR EXISTING STYLES AS-IS */ ?>

/* ========================
   GLOBAL MODERN SaaS STYLE
======================== */

body{
    font-family: "Segoe UI", Inter, Arial, sans-serif;
    margin:0;
    background:#f5f7fb;
    color:#111827;
}

/* Dashboard Wrapper */

.container{
    width:92%;
    max-width:1050px;
    margin:auto;
    padding:40px 0;
}

/* Typography Hierarchy */

h2{
    font-size:22px;
    font-weight:600;
    margin-bottom:22px;
}

/* Upload Card */

.box{
    background:white;

    padding:32px;

    border-radius:20px;

    box-shadow:
    0 10px 35px rgba(0,0,0,0.05);

    margin-bottom:45px;

    transition:0.3s ease;
}

.box:hover{
    transform:translateY(-4px);
}

/* Input Fields */

input, textarea{
    width:100%;

    padding:14px;

    border-radius:10px;

    border:1px solid #e5e7eb;

    margin-top:14px;

    font-size:14px;

    transition:0.3s;
}

input:focus,
textarea:focus{
    outline:none;
    border-color:#2563eb;

    box-shadow:0 0 0 3px rgba(37,99,235,0.08);
}

/* Upload Button */

button{
    width:100%;

    padding:14px;

    margin-top:18px;

    border:none;

    border-radius:12px;

    background:linear-gradient(135deg,#2563eb,#4f46e5);

    color:white;

    font-weight:600;

    font-size:15px;

    cursor:pointer;

    transition:0.3s;
}

button:hover{
    opacity:0.9;
    transform:scale(1.01);
}

/* Message Box */

.msg{
    padding:12px;
    border-radius:8px;
    font-size:14px;
    margin-top:12px;
}

.success{
    background:#ecfdf5;
    color:#065f46;
}

.error{
    background:#fef2f2;
    color:#991b1b;
}

/* Gesture Card */

.gesture-card{
    display:flex;
    gap:20px;
    align-items:center;

    background:white;

    padding:22px;

    border-radius:18px;

    box-shadow:
    0 8px 30px rgba(0,0,0,0.05);

    margin-bottom:28px;

    transition:0.3s;
}

.gesture-card:hover{
    transform:translateY(-4px);
}

/* Thumbnail */

.gesture-thumb{
    width:100px;
    height:100px;

    border-radius:14px;

    object-fit:cover;

    background:#111;
}

/* Card Info */

.card-info{
    flex:1;
}

.card-info p{
    font-size:14px;
    line-height:1.6;
    color:#374151;
}

/* Status Colors */

.status{
    font-size:13px;
    margin-top:8px;
}

.approved{
    color:#059669;
}

.pending{
    color:#d97706;
}

.rejected{
    color:#dc2626;
}

/* Action Buttons */

.card-actions a{
    display:inline-block;

    padding:7px 16px;

    border-radius:8px;

    color:white;
    text-decoration:none;

    font-size:13px;

    margin-right:6px;
}

.delete{
    background:#ef4444;
}

.edit{
    background:#f59e0b;
}

/* Back Link */

a.back{
    display:block;
    text-align:center;
    margin-top:50px;
    color:#2563eb;
    font-weight:600;
    text-decoration:none;
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>
<body>

<div class="container">

    <!-- UPLOAD / EDIT BOX -->
    <div class="box">
        <h2><?= $edit_mode ? 'Edit Gesture' : 'Upload Gesture / Voice' ?></h2>
        <?php if($success) echo "<p class='msg success'>$success</p>"; ?>
        <?php if($error) echo "<p class='msg error'>$error</p>"; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="gesture_name"
                   value="<?= $edit_mode ? htmlspecialchars($edit_name) : '' ?>"
                   placeholder="Gesture / Voice Name" required>
            <textarea name="description" rows="3" required><?= $edit_mode ? htmlspecialchars($edit_desc) : '' ?></textarea>

            <?php if(!$edit_mode) { ?>
                <input type="file" name="gesture_file" accept=".jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.ogg,.mp3,.wav,.json" required>
                <button type="submit" name="submit">Upload</button>
            <?php } else { ?>
                <input type="hidden" name="gesture_id" value="<?= $editID ?>">
                <button type="submit" name="update">Update</button>
                <a href="upload_gestures.php" class="back">Cancel Edit</a>
            <?php } ?>
        </form>
    </div>

    <!-- PENDING GESTURES -->
    <?php if(mysqli_num_rows($pending_gestures) > 0) : ?>
    <h2>Pending Gestures (From Users)</h2>
    <?php while($row = mysqli_fetch_assoc($pending_gestures)) : ?>
    <div class="gesture-card">
        <?php 
        $ext = strtolower(pathinfo($row['filename'], PATHINFO_EXTENSION));
        if(in_array($ext,['mp4','mov','avi','mkv','webm','ogg'])) echo "<video class='gesture-thumb' src='{$row['filename']}' controls></video>";
        elseif(in_array($ext, ['mp3','wav'])) echo "<audio class='gesture-thumb' src='{$row['filename']}' controls></audio>";
        elseif($ext == 'gif') echo "<img class='gesture-thumb' src='{$row['filename']}' alt='Gesture GIF'>";
        elseif($ext == 'json') echo "<div class='gesture-thumb' style='background:#555;display:flex;align-items:center;justify-content:center;'>JSON</div>";
        else echo "<img class='gesture-thumb' src='{$row['filename']}' />";
        ?>

        <div class="card-info">
            <form method="POST">
                <input type="hidden" name="gesture_id" value="<?= $row['gesture_id'] ?>">
                <input type="text" name="gesture_name" placeholder="Gesture Name" required>
                <input type="text" name="description" placeholder="Meaning" required>
                <button type="submit" name="approve_pending">Approve & Update</button>
            </form>
            <p class="status pending">Status: <?= ucfirst($row['status']) ?></p>
        </div>
    </div>
    <?php endwhile; endif; ?>

    <!-- USER'S OWN GESTURES -->
    <h2>Your Uploaded Gestures</h2>
    <?php while ($row = mysqli_fetch_assoc($gestures)) { ?>
    <div class="gesture-card">
        <?php 
        $ext = strtolower(pathinfo($row['filename'], PATHINFO_EXTENSION));
        if(in_array($ext,['mp4','mov','avi','mkv','webm','ogg'])) echo "<video class='gesture-thumb' src='".$row['filename']."' controls muted></video>";
        elseif(in_array($ext, ['mp3','wav'])) echo "<audio class='gesture-thumb' src='".$row['filename']."' controls></audio>";
        elseif($ext == 'json') echo "<div class='gesture-thumb' style='background:#555;display:flex;align-items:center;justify-content:center;'>JSON</div>";
        else echo "<img class='gesture-thumb' src='".$row['filename']."' />";
        ?>
        <div class="card-info">
            <p><b><?= htmlspecialchars($row['gesture_name']) ?></b></p>
            <p><?= htmlspecialchars($row['description']) ?></p>
            <p class="status <?= $row['status'] ?>">Status: <?= ucfirst($row['status']) ?></p>
            <div class="card-actions">
                <a href="upload_gestures.php?edit=<?= $row['gesture_id'] ?>" class="edit">Edit</a>
                <a href="upload_gestures.php?delete=<?= $row['gesture_id'] ?>" class="delete"
                   onclick="return confirm('Delete Gesture?')">Delete</a>
            </div>
        </div>
    </div>
    <?php } ?>

    <a href="interpreter_home.php" class="back">⬅ Back to Home</a>

</div>
</body>
</html>