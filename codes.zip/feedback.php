<?php
session_start();
include("config.php");

// Only logged-in users
if (!isset($_SESSION['id']) || ($_SESSION['role'] !== 'user' && $_SESSION['role'] !== 'learner')) {
    echo "<script>alert('Please login first!'); window.location.href='login.php';</script>";
    exit();
}

$user_id = $_SESSION['id'];
$message = "";

// Handle new feedback submission
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $feedback = mysqli_real_escape_string($conn, $_POST['feedback']);

    if (!empty($feedback)) {
        $query = "INSERT INTO feedback (user_id, feedback, submitted_at) VALUES ('$user_id', '$feedback', NOW())";
        if (mysqli_query($conn, $query)) {
            $message = "Thank you! Your feedback has been submitted successfully.";
        } else {
            $message = "Error submitting feedback. Please try again.";
        }
    } else {
        $message = "Feedback cannot be empty.";
    }
}

$q = mysqli_query($conn, "SELECT * FROM feedback WHERE user_id='$user_id' ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Feedback | GestureLink</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Inter',sans-serif;
    background: linear-gradient(135deg, #0f172a, #1e293b);
    color:#1e293b;
    display:flex;
    min-height:100vh;
}

/* ===== SIDEBAR ===== */
.sidebar{
    width:240px;
    background:#0f172a;
    padding:30px 20px;
    color:#fff;
    position:fixed;
    height:100%;
}

.sidebar h2{
    font-size:18px;
    margin-bottom:30px;
    font-weight:600;
    letter-spacing:0.5px;
}

.sidebar a{
    display:block;
    color:#cbd5e1;
    text-decoration:none;
    padding:10px 12px;
    border-radius:6px;
    margin-bottom:10px;
    font-size:14px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#1e293b;
    color:#fff;
}

/* ===== MAIN CONTENT ===== */
.main{
    margin-left:240px;
    width:100%;
    padding:40px;
}

/* ===== HEADER ===== */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
    color:#fff;
}

.header h1{
    font-size:22px;
    font-weight:600;
}

.home-btn{
    text-decoration:none;
    background:#2563eb;
    color:#fff;
    padding:8px 16px;
    border-radius:6px;
    font-size:14px;
    transition:0.3s;
}

.home-btn:hover{
    background:#1d4ed8;
}

/* ===== CARD ===== */
.card{
    background:rgba(255,255,255,0.95);
    border-radius:12px;
    padding:30px;
    box-shadow:0 15px 35px rgba(0,0,0,0.2);
    margin-bottom:30px;
}

/* ===== SECTION TITLE ===== */
.section-title{
    font-size:18px;
    font-weight:600;
    margin-bottom:20px;
    color:#0f172a;
}

/* ===== MESSAGE ===== */
.msg{
    padding:12px;
    background:#ecfdf5;
    color:#065f46;
    border-radius:6px;
    margin-bottom:15px;
    font-size:14px;
}

/* ===== TEXTAREA ===== */
textarea{
    width:100%;
    height:120px;
    padding:12px;
    border-radius:6px;
    border:1px solid #d1d5db;
    font-size:14px;
    resize:none;
}

textarea:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 2px rgba(37,99,235,0.2);
}

/* ===== BUTTON ===== */
button{
    margin-top:12px;
    background:#2563eb;
    color:#fff;
    border:none;
    padding:10px 18px;
    border-radius:6px;
    font-size:14px;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#1d4ed8;
}

/* ===== FEEDBACK ITEM ===== */
.feedback-item{
    border-left:4px solid #2563eb;
    background:#f8fafc;
    padding:15px 18px;
    border-radius:6px;
    margin-bottom:15px;
}

.feedback-text{
    font-size:14px;
    line-height:1.6;
}

.admin-reply{
    background:#e0f2fe;
    border-left:4px solid #0284c7;
    padding:10px;
    border-radius:6px;
    font-size:13px;
    margin-top:8px;
}

.feedback-time{
    font-size:12px;
    color:#64748b;
    margin-top:6px;
    display:block;
}

/* Responsive */
@media(max-width:900px){
    .sidebar{
        display:none;
    }
    .main{
        margin-left:0;
        padding:20px;
    }
}

</style>

<script src="js/smart-voice-system.js"></script>

</head>

<body>

<div class="sidebar">
    <h2>GestureLink</h2>
    <a href="user_home.php">Dashboard</a>
    <a href="#" style="background:#1e293b;color:#fff;">Feedback</a>
    <a href="logout.php">Logout</a>
</div>

<div class="main">

    <div class="header">
        <h1>Feedback Center</h1>
        <a href="user_home.php" class="home-btn">Home</a>
    </div>

    <div class="card">
        <div class="section-title">Submit Your Feedback</div>

        <?php 
        if ($message != "") {
            echo "<div class='msg'>$message</div>";
        }
        ?>

        <form method="POST">
            <textarea name="feedback" placeholder="Share your experience or suggestions..." required></textarea>
            <button type="submit">Submit Feedback</button>
        </form>
    </div>

    <div class="card">
        <div class="section-title">Your Previous Feedback</div>

        <?php
        if(mysqli_num_rows($q) > 0){
            while($row = mysqli_fetch_assoc($q)){
        ?>
            <div class="feedback-item">
                <div class="feedback-text">
                    <?= nl2br($row['feedback']); ?>
                </div>

                <?php if(!empty($row['reply'])){ ?>
                    <div class="admin-reply">
                        <strong>Admin Reply:</strong><br>
                        <?= nl2br($row['reply']); ?>
                    </div>
                <?php } ?>

                <span class="feedback-time">
                    Submitted on: <?= $row['submitted_at']; ?>
                </span>
            </div>
        <?php
            }
        } else {
            echo "<p style='font-size:14px; color:#64748b;'>No feedback submitted yet.</p>";
        }
        ?>
    </div>

</div>

</body>
</html>