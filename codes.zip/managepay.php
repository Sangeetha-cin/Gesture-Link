<?php
session_start();
include("config.php");

/* =========================
   SECURITY – only session coordinator
========================= */
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'session') {
    header("Location: login.php");
    exit();
}

$coordinatorId = $_SESSION['id']; // session_coordinator_id

/* =========================
   HANDLE TRANSFER PAYMENT
========================= */
if (isset($_POST['transfer_money'])) {

    $sessionId   = (int)$_POST['session_id'];
    $amount      = (float)$_POST['amount'];
    $caregiverId = isset($_POST['caregiver_id']) ? (int)$_POST['caregiver_id'] : 0;

    if ($caregiverId > 0) {
        $profit = round($amount * 0.10, 2);
        $payToCaregiver = round($amount - $profit, 2);

        mysqli_query($conn, "
            UPDATE sessions 
            SET transferred = 1 
            WHERE id = $sessionId
              AND session_coordinator_id = $coordinatorId
        ");

        echo "<script>alert(
            '₹$payToCaregiver sent to Caregiver ID $caregiverId. 
System profit: ₹$profit'
        );</script>";
    } else {
        echo "<script>alert('Cannot transfer: No caregiver assigned for this session.');</script>";
    }
}

/* =========================
   AUTO UPDATE – ONLY THIS COORDINATOR
========================= */
mysqli_query($conn, "
    UPDATE sessions 
    SET status = 'paid'
    WHERE status = 'pending'
      AND session_coordinator_id = $coordinatorId
");

/* =========================
   FETCH PAYMENTS – ONLY THIS COORDINATOR
========================= */
$sql = "
SELECT 
    s.id AS session_id,
    s.learner_id,
    lu.name AS learner_name,
    lu.email AS learner_email,
    s.amount,
    s.status,
    s.session_date,
    s.session_time,
    s.caregiver_id,
    (SELECT name FROM users WHERE id = s.caregiver_id) AS caregiver_name,
    s.transferred
FROM sessions s
LEFT JOIN users lu ON s.learner_id = lu.id
WHERE s.session_coordinator_id = $coordinatorId
  AND s.caregiver_id > 0   -- <-- ADD THIS LINE
ORDER BY s.session_date DESC, s.session_time DESC
";


$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
<title>Payment Management</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;}
body{
    margin:0;
    font-family:'Poppins',sans-serif;
    min-height:100vh;
    background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
    padding:30px;
}
.wrapper{
    max-width:1300px;
    margin:auto;
    background:#ffffff;
    border-radius:20px;
    box-shadow:0 20px 60px rgba(0,0,0,.35);
    overflow:hidden;
}
.header{
    background:linear-gradient(135deg,#667eea,#764ba2);
    color:#fff;
    padding:30px;
    text-align:center;
    position:relative;
}
.header h2{margin:0;font-weight:600;}
.badge{
    background:#00e676;
    color:#000;
    padding:4px 12px;
    border-radius:20px;
    font-size:12px;
    margin-left:8px;
}
.back-btn{
    position:absolute;
    right:20px;
    top:20px;
    background:#fff;
    color:#333;
    padding:8px 16px;
    border-radius:25px;
    text-decoration:none;
    font-size:13px;
    font-weight:600;
}
.back-btn:hover{background:#000;color:#fff}
.content{padding:35px;}
.table-box{
    background:#f8f9ff;
    border-radius:16px;
    box-shadow:0 10px 30px rgba(0,0,0,.12);
    overflow:hidden;
}
table{width:100%;border-collapse:collapse;}
thead{
    background:linear-gradient(135deg,#141e30,#243b55);
    color:#fff;
}
th{padding:14px;font-size:12px;text-transform:uppercase;}
td{
    padding:12px;
    text-align:center;
    font-size:14px;
    border-bottom:1px solid #eee;
}
tbody tr:nth-child(even){background:#f5f7ff;}
tbody tr:hover{background:#eaf0ff;}
.paid{
    color:#1b5e20;
    background:#c8e6c9;
    padding:5px 14px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}
.pending{
    color:#e65100;
    background:#ffe0b2;
    padding:5px 14px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}
.btn-transfer{
    background:linear-gradient(135deg,#00c853,#009624);
    border:none;
    color:#fff;
    padding:7px 16px;
    border-radius:20px;
    font-weight:600;
    cursor:pointer;
}
.done{color:#1565c0;font-weight:700;}
.unknown{color:#e53935;font-weight:600;}
.footer-note{text-align:center;margin-top:18px;font-size:13px;color:#555;}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>
<div class="wrapper">
<div class="header">
    <a href="session_home.php" class="back-btn">⬅ Back</a>
    <h2>Payment Management <span class="badge">SESSION COORDINATOR</span></h2>
</div>

<div class="content">
<div class="table-box">
<table>
<thead>
<tr>
    <th>Session</th>
    <th>Learner ID</th>
    <th>Learner Name</th>
    <th>Email</th>
    <th>Date</th>
    <th>Time</th>
    <th>Amount</th>
    <th>Profit</th>
    <th>Caregiver Gets</th>
    <th>Status</th>
    <th>Caregiver</th>
    <th>Transfer</th>
</tr>
</thead>
<tbody>

<?php if (mysqli_num_rows($result) > 0) { ?>
<?php while ($row = mysqli_fetch_assoc($result)) {
    $profit = round($row['amount'] * 0.10, 2);
    $cg = round($row['amount'] - $profit, 2);
?>
<tr>
<td><?= $row['session_id'] ?></td>
<td><?= $row['learner_id'] ?></td>
<td><?= htmlspecialchars($row['learner_name'] ?? 'N/A') ?></td>
<td><?= htmlspecialchars($row['learner_email'] ?? 'N/A') ?></td>
<td><?= date("d-m-Y", strtotime($row['session_date'])) ?></td>
<td><?= date("h:i A", strtotime($row['session_time'])) ?></td>
<td>₹<?= number_format($row['amount'],2) ?></td>
<td>₹<?= number_format($profit,2) ?></td>
<td>₹<?= number_format($cg,2) ?></td>
<td><span class="<?= $row['status'] ?>"><?= strtoupper($row['status']) ?></span></td>
<td>
<?= htmlspecialchars($row['caregiver_name'] ?? 'Unknown Caregiver') ?> (ID: <?= $row['caregiver_id'] ?>)
</td>

<td>
<?php 
if (!empty($row['caregiver_id']) && $row['transferred'] == 0) { ?>
<form method="post">
<input type="hidden" name="session_id" value="<?= $row['session_id'] ?>">
<input type="hidden" name="amount" value="<?= $row['amount'] ?>">
<input type="hidden" name="caregiver_id" value="<?= $row['caregiver_id'] ?>">
<button name="transfer_money" class="btn-transfer">Transfer</button>
</form>
<?php } elseif (empty($row['caregiver_id'])) { ?>
<span class="done">No Caregiver</span>
<?php } else { ?>
<span class="done">Transferred</span>
<?php } ?>
</td>
</tr>
<?php } } else { ?>
<tr><td colspan="12">❌ No payment records found.</td></tr>
<?php } ?>

</tbody>
</table>
</div>

<div class="footer-note">
✔ Managed by <b>Session Coordinator ID: <?= $coordinatorId ?></b>
</div>
</div>
</div>
</body>
</html>
