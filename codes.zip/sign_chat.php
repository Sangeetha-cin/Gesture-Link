<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include("config.php");

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['id'];

mysqli_query($conn, "
    UPDATE gestures
    SET message_status='read'
    WHERE user_id='$userId'
    AND message_status='unread'
");

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'user') {
    echo "<script>alert('Please login as Learner first!'); window.location.href='login.php';</script>";
    exit();
}

$gestureFile = '';
$gestureName = '';
$gestureMeaning = '';
$voiceFile = '';
$uploadMessage = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['upload_video']) && isset($_FILES['video'])) {
        $file = $_FILES['video'];
        $folder = "gestures/";
        $type = "video";
    }
    elseif (isset($_POST['upload_voice']) && isset($_FILES['voice'])) {
        $file = $_FILES['voice'];
        $folder = "voices/";
        $type = "voice";
    }
    else {
        $error = "Invalid upload option!";
        $file = null;
    }

    if ($file) {
        if (!is_dir($folder)) mkdir($folder, 0777, true);

        if ($file["error"] !== UPLOAD_ERR_OK) {
            $error = "Upload failed!";
        } else {

            $originalName = basename($file["name"]);
            $safeName = preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $originalName);
            $targetFile = $folder . time() . "_" . $safeName;
            $ext = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

            if ($type === 'video' && !in_array($ext, ['mp4','mov','webm','ogg','avi','mkv'])) {
                $error = "Invalid video format!";
            } elseif ($type === 'voice' && !in_array($ext, ['mp3','wav','ogg','m4a'])) {
                $error = "Invalid audio format!";
            } elseif (!move_uploaded_file($file["tmp_name"], $targetFile)) {
                $error = "Upload failed!";
            } else {

                mysqli_query($conn, "
                    INSERT INTO gestures 
                    (user_id, interpreter_id, gesture_name, description, filename, voice_filename, status, message_status) 
                    VALUES 
                    (
                        {$_SESSION['id']},
                        0,
                        'Meaning',
                        'Pending approval',
                        '".($type === 'video' ? mysqli_real_escape_string($conn,$targetFile) : '')."',
                        '".($type === 'voice' ? mysqli_real_escape_string($conn,$targetFile) : '')."',
                        'pending',
                        'read'
                    )
                ");
            }
        }
    }
}

$res = mysqli_query($conn, "
    SELECT gesture_name, description, filename, voice_filename, status 
    FROM gestures 
    WHERE user_id={$_SESSION['id']}
    ORDER BY gesture_id DESC 
    LIMIT 1
");

if ($res && mysqli_num_rows($res) > 0) {
    $gesture = mysqli_fetch_assoc($res);
    $gestureFile = $gesture['filename'];
    $voiceFile = $gesture['voice_filename'];
    $gestureName = $gesture['gesture_name'];
    $gestureMeaning = $gesture['description'];
    $uploadMessage = ($gesture['status'] === 'approved')
        ? "Gesture Identified Successfully"
        : "Uploaded Successfully. Waiting for Approval.";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>SignChat | Recognition</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

<style>
*{margin:0;padding:0;box-sizing:border-box;}

body{
    font-family:'Inter',sans-serif;
    background:linear-gradient(135deg,#0b1f3a,#142850,#1b3358);
    min-height:100vh;
    color:#1f2937;
}

/* HEADER */
.header{
    padding:20px 70px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    background:rgba(255,255,255,0.08);
    backdrop-filter:blur(10px);
    border-bottom:1px solid rgba(255,255,255,0.1);
}

.logo{
    font-size:22px;
    font-weight:800;
    color:white;
    letter-spacing:1px;
}

.dashboard-btn{
    padding:10px 22px;
    background:linear-gradient(90deg,#2563eb,#3b82f6);
    color:white;
    text-decoration:none;
    border-radius:8px;
    font-size:14px;
    font-weight:600;
    transition:0.3s;
}
.dashboard-btn:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 25px rgba(37,99,235,0.4);
}

/* MAIN CARD */
.container{
    max-width:1050px;
    margin:80px auto;
    background:white;
    padding:55px;
    border-radius:24px;
    box-shadow:0 30px 80px rgba(0,0,0,0.4);
}

h2{
    text-align:center;
    margin-bottom:45px;
    font-size:28px;
    font-weight:800;
}

/* UPLOAD GRID */
.upload-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:35px;
}

.upload-card{
    padding:35px;
    border-radius:20px;
    background:linear-gradient(145deg,#ffffff,#f3f4f6);
    border:1px solid #e5e7eb;
    text-align:center;
    transition:0.4s;
}

.upload-card:hover{
    transform:translateY(-8px);
    box-shadow:0 20px 50px rgba(0,0,0,0.15);
}

.upload-card h3{
    margin-bottom:18px;
    font-size:18px;
    font-weight:700;
}

input[type=file]{
    margin:18px 0;
}

button{
    padding:12px 28px;
    border:none;
    border-radius:10px;
    background:linear-gradient(90deg,#111827,#374151);
    color:white;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}
button:hover{
    transform:scale(1.07);
}

/* MESSAGE */
.message,.error{
    margin-top:35px;
    padding:16px;
    border-radius:10px;
    text-align:center;
    font-weight:600;
}
.message{
    background:#e0f2fe;
    color:#075985;
}
.error{
    background:#fee2e2;
    color:#991b1b;
}

/* PREVIEW */
.preview-section{
    margin-top:55px;
    padding-top:35px;
    border-top:1px solid #e5e7eb;
    text-align:center;
}

.preview-title{
    font-size:22px;
    font-weight:800;
    margin-bottom:15px;
}

.meaning-box{
    display:inline-block;
    padding:16px 24px;
    border-radius:12px;
    background:#f1f5f9;
    margin-bottom:30px;
    font-size:15px;
}

.preview-media{
    max-width:360px;
    margin:auto;
}

.preview-media video,
.preview-media audio{
    width:100%;
    border-radius:14px;
    box-shadow:0 20px 40px rgba(0,0,0,0.3);
}

/* FOOTER */
.footer{
    margin-top:100px;
    padding:35px;
    text-align:center;
    background:#0b1f3a;
    color:#94a3b8;
    font-size:14px;
    letter-spacing:0.5px;
}

@media(max-width:900px){
    .upload-grid{grid-template-columns:1fr;}
    .container{padding:30px;}
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<div class="header">
    <div class="logo">SignChat Recognition</div>
    <a href="user_home.php" class="dashboard-btn">Dashboard</a>
</div>

<div class="container">

<h2>Gesture & Voice Recognition System</h2>

<div class="upload-grid">

<form method="POST" enctype="multipart/form-data" class="upload-card">
    <h3>Upload Gesture Video</h3>
    <input type="file" name="video" accept="video/*" required>
    <button type="submit" name="upload_video">Analyze</button>
</form>

<form method="POST" enctype="multipart/form-data" class="upload-card">
    <h3>Upload Voice Command</h3>
    <input type="file" name="voice" accept="audio/*" required>
    <button type="submit" name="upload_voice">Convert</button>
</form>

</div>

<?php if ($error) echo "<div class='error'>$error</div>"; ?>
<?php if ($uploadMessage) echo "<div class='message'>$uploadMessage</div>"; ?>

<?php if ($gestureName): ?>
<div class="preview-section">
    <div class="preview-title"><?= htmlspecialchars($gestureName) ?></div>
    <div class="meaning-box"><?= htmlspecialchars($gestureMeaning) ?></div>

    <div class="preview-media">
        <?php if ($gestureFile): ?>
            <video controls>
                <source src="<?= $gestureFile ?>">
            </video>
        <?php endif; ?>

        <?php if ($voiceFile): ?>
            <audio controls>
                <source src="<?= $voiceFile ?>">
            </audio>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

</div>

<div class="footer">
© <?= date("Y") ?> SignChat Enterprise Platform | Intelligent & Secure AI Recognition
</div>

</body>
</html>