<?php
include("config.php");

// Handle Accept / Reject actions safely
if(isset($_GET['action']) && isset($_GET['id'])){
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    if($action == 'accept'){
        $update = mysqli_query($conn, "UPDATE users SET status='accepted' WHERE id=$id");
    } elseif($action == 'reject'){
        $update = mysqli_query($conn, "UPDATE users SET status='rejected' WHERE id=$id");
    }

    if(!$update){
        die("Database update failed: " . mysqli_error($conn));
    }

    // 🔥 Redirect back to same table section
    header("Location: view_users.php#userTable");
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM users WHERE role='user'");
if(!$result){
    die("Database query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Management – GestureLink</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Inter',sans-serif;
    scroll-behavior:smooth; /* 🔥 smooth scroll */
}

body{
    background: linear-gradient(135deg,#eef2f7,#f8fafc);
    color:#1e293b;
}

/* TOP BAR */
.topbar{
    background:#0f172a;
    padding:20px 60px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    box-shadow:0 8px 30px rgba(0,0,0,0.1);
}

.topbar h1{
    font-size:20px;
    font-weight:600;
    letter-spacing:0.5px;
}

.topbar a{
    background:#2563eb;
    color:white;
    padding:8px 18px;
    border-radius:8px;
    text-decoration:none;
    font-size:13px;
    font-weight:500;
    transition:0.3s ease;
}

.topbar a:hover{
    background:#1d4ed8;
    transform:translateY(-2px);
}

/* MAIN CARD */
.main-container{
    width:95%;
    max-width:1250px;
    margin:60px auto;
    background:rgba(255,255,255,0.85);
    backdrop-filter:blur(10px);
    padding:50px;
    border-radius:20px;
    box-shadow:0 25px 60px rgba(0,0,0,0.08);
    border:1px solid rgba(255,255,255,0.6);
}

.main-container h2{
    font-size:26px;
    margin-bottom:35px;
    font-weight:600;
    color:#0f172a;
}

/* TABLE */
.table-wrapper{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
    font-size:14px;
}

thead{
    background:#f1f5f9;
}

th{
    padding:18px;
    text-align:left;
    font-weight:600;
    color:#334155;
    border-bottom:2px solid #e2e8f0;
    font-size:13px;
    text-transform:uppercase;
    letter-spacing:0.5px;
}

td{
    padding:18px;
    border-bottom:1px solid #f1f5f9;
    font-weight:400;
    color:#475569;
}

tbody tr{
    transition:all 0.25s ease;
}

tbody tr:hover{
    background:#f8fafc;
}

/* STATUS BADGES */
.status-pending,
.status-accepted,
.status-rejected{
    padding:6px 14px;
    border-radius:30px;
    font-size:12px;
    font-weight:600;
    display:inline-block;
}

.status-pending{
    background:#fff7ed;
    color:#ea580c;
}

.status-accepted{
    background:#ecfdf5;
    color:#16a34a;
}

.status-rejected{
    background:#fef2f2;
    color:#dc2626;
}

/* BUTTONS */
.button{
    padding:7px 14px;
    border-radius:8px;
    font-size:12px;
    font-weight:600;
    text-decoration:none;
    margin-right:6px;
    transition:all 0.25s ease;
    display:inline-block;
}

.accept{
    background:#16a34a;
    color:white;
}

.accept:hover{
    background:#15803d;
}

.reject{
    background:#dc2626;
    color:white;
}

.reject:hover{
    background:#b91c1c;
}

/* FOOTER */
.footer{
    text-align:center;
    padding:30px;
    margin-top:60px;
    font-size:13px;
    color:#64748b;
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>
<body>

<div class="topbar">
    <h1>GestureLink – User Management</h1>
    <a href="adminhome.php">← Back to Dashboard</a>
</div>

<!-- 🔥 ID ADDED HERE -->
<div class="main-container" id="userTable">
    <h2>Registered Users</h2>

    <div class="table-wrapper">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Login Count</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>

        <?php
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
                $status_class = "status-".strtolower($row['status']);
                echo "<tr>";
                echo "<td data-label='ID'>".$row['id']."</td>";
                echo "<td data-label='Full Name'>".$row['name']."</td>";
                echo "<td data-label='Email'>".$row['email']."</td>";
                echo "<td data-label='Status'><span class='$status_class'>".$row['status']."</span></td>";
                echo "<td data-label='Login Count'>".$row['login_count']."</td>";
                echo "<td data-label='Actions'>
                        <a class='button accept' href='?action=accept&id=".$row['id']."'>Accept</a>
                        <a class='button reject' href='?action=reject&id=".$row['id']."'>Reject</a>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6' style='text-align:center;padding:30px;'>No users found.</td></tr>";
        }
        ?>

        </tbody>
    </table>
    </div>
</div>

<div class="footer">
    © <?= date('Y') ?> GestureLink. All Rights Reserved.
</div>

</body>
</html>