<?php
session_start();
include("config.php");

// Only caregiver can start call
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'caregiver') {
    die("Access denied");
}

// Check application id
if (!isset($_POST['application_id'])) {
    die("Application ID missing");
}

$application_id = (int) $_POST['application_id'];
$caregiver_id   = $_SESSION['id'];

// 1️⃣ Check if a room already exists
$sql = "SELECT call_room FROM applications WHERE id = ? AND assigned_caregiver_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $application_id, $caregiver_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if(!empty($row['call_room'])){
    // Room already exists, reuse it
    $room_link = $row['call_room'];
} else {
    // Create new room
    $room_link = "https://meet.jit.si/gesturelink_" . $application_id . "_" . time();
}

// 2️⃣ Update DB with call_status and call_room
$sql2 = "UPDATE applications 
         SET call_status = 'started',
             call_room   = ?
         WHERE id = ? AND assigned_caregiver_id = ?";
$stmt2 = $conn->prepare($sql2);
$stmt2->bind_param("sii", $room_link, $application_id, $caregiver_id);

if(!$stmt2->execute()){
    die("DB Error: " . $stmt2->error);
}

// 3️⃣ Redirect back to caregiver classes
header("Location: caregiver_classes.php?call=started");
exit();
