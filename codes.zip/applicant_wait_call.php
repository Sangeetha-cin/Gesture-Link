<?php
session_start();
include("config.php");

if (!isset($_SESSION['id']) || $_SESSION['role'] != 'applicant') {
    exit("Unauthorized");
}

$userId = $_SESSION['id'];

$sql = "SELECT call_status, call_room 
        FROM applications 
        WHERE user_id=$userId 
        ORDER BY id DESC LIMIT 1";

$res = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($res);

$callStatus = $row['call_status'] ?? 'idle';
$room = $row['call_room'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
<title>Waiting for Caregiver</title>
</head>
<body>

<h2>📞 Video Call Status</h2>

<?php if($callStatus == 'calling'): ?>
    <h3>👩‍⚕️ Caregiver is calling you!</h3>
    <a href="video_room.php?room=<?php echo $room; ?>&role=applicant">
        <button>Join Video Call</button>
    </a>
<?php else: ?>
    <p>Waiting for caregiver to start the call...</p>
    <script>
        setTimeout(()=>location.reload(),5000);
    </script>
<?php endif; ?>

</body>
</html>
