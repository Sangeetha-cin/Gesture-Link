<?php
session_start();
include("config.php");

// ===== ROLE CHECK =====
if (!isset($_SESSION['id']) || 
    ($_SESSION['role'] !== 'learner' && $_SESSION['role'] !== 'user')) {
    header("Location: index.php");
    exit();
}

$applicantId = $_SESSION['id'];

// ===== SESSION FOR PAYMENT =====
if (!isset($_SESSION['payment_done'])) {
    $_SESSION['payment_done'] = false;
}

// ===== PREFILL FORM IF RETURNING FROM PAYMENT =====
$prefill = isset($_SESSION['paid_form']) ? $_SESSION['paid_form'] : [];

// ===== APPLY FORM PROCESS =====
$message = "";

if (isset($_POST['apply'])) {

    if (!isset($_POST['payment_done']) || $_POST['payment_done'] != "1") {
        $message = "❌ Please complete GLG Pay payment before applying.";
    } 
    else {

        // --------- GET FORM DATA ----------
        $session_date = mysqli_real_escape_string($conn, $_POST['session_date'] ?? '');
        $hour   = $_POST['hour'] ?? '12';
        $minute = $_POST['minute'] ?? '00';
        $ampm   = $_POST['ampm'] ?? 'AM';
        $period = mysqli_real_escape_string($conn, $_POST['period'] ?? '30 min');

// Set amount based on period
// ✅ GET AMOUNT FROM FORM (set by JS)
$amount = $_POST['amount'] ?? '149';
$amount = (int) str_replace('₹', '', $amount);

// ✅ SAFETY FALLBACK (if JS or form fails)
if ($amount <= 0) {
    switch($period){
        case '30 min': $amount = 149; break;
        case '45 min': $amount = 249; break;
        case '1 hour': $amount = 399; break;
        default: $amount = 149;
    }
}


        // convert time to 24 hour format
        $timeStr = "$hour:$minute $ampm";
        $session_time = date("H:i:s", strtotime($timeStr));

        // ==================================================
        // ✅ PREVENT DUPLICATE APPLICATION (only pending/approved)
        // ==================================================
        $dupChk = mysqli_query($conn, "
            SELECT id FROM applications 
            WHERE user_id = $applicantId
            AND session_date = '$session_date'
            AND session_time = '$session_time'
            AND assigned_status IN (0,1)
        ");

        if (!$dupChk) {
            $message = "❌ DB Error: " . mysqli_error($conn);
        } elseif (mysqli_num_rows($dupChk) > 0) {
            $message = "❌ You already applied for this time slot.";
        }
        else {

            // ==================================================
            // ✅ INSERT INTO APPLICATIONS TABLE
            // You can assign caregiver_id here if needed, else 0
            // ==================================================
            $assignedCaregiverId = 0; // change to actual caregiver_id if assigning automatically

            $query = "
    INSERT INTO applications 
    (user_id, session_date, session_time, period, amount, assigned_status, assigned_caregiver_id, created_at)
    VALUES 
    ($applicantId, '$session_date', '$session_time', '$period', $amount, 0, $assignedCaregiverId, NOW())
";


            if (mysqli_query($conn, $query)) {

                $message = "✅ Live class application sent! Waiting for coordinator approval.";

                unset($_SESSION['paid_form']);      
                $_SESSION['payment_done'] = false;   

            } else {
                $message = "❌ Error: " . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Live Class – Gesture Link</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
/* 🔒 STYLES NOT TOUCHED */
body, html { margin:0; padding:0; font-family:'Poppins',sans-serif; background: url('assets/care.jpg') no-repeat center center fixed; background-size: cover; color: white; }
input[type="date"] { background: rgba(0,0,0,0.5); color: white; padding: 10px; border-radius: 8px; border: none; }
input[type="date"]::-webkit-calendar-picker-indicator { filter: invert(1); opacity: 1; }
.overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index:0; }
.wrapper { position: relative; z-index:2; min-height: 100vh; display: flex; flex-direction: column; align-items: center; padding: 30px 0; }
.back-btn{ position: absolute; top:20px; left:20px; padding:10px 18px; background:#0044ff; border-radius:10px; color:white; text-decoration:none; font-weight:600; transition:0.3s; z-index:5; }
.back-btn:hover{ background:#002699; }
.form-container{ width: 95%; max-width: 550px; background: rgba(0,0,0,0.85); padding: 40px 30px; border-radius: 20px; box-shadow: 0 15px 40px rgba(0,0,0,0.6); backdrop-filter: blur(6px); border: 1px solid rgba(255,255,255,0.2); position: relative; margin-bottom: 40px; }
.form-container h2{ text-align:center; font-size:28px; color:#00c6ff; font-weight:700; margin-bottom:30px; }
.message{ text-align:center; margin-bottom:20px; font-size:16px; font-weight:600; }
.form-container label{ display:block; margin:12px 0 6px; font-weight:600; color:#00c6ff; }
.form-container input, .form-container select{ width:100%; padding:12px; margin-bottom:18px; border-radius:10px; border:none; font-size:16px; background: rgba(255,255,255,0.1); color:white; transition:0.3s; }
.form-container input:focus, .form-container select:focus{ background: rgba(0,198,255,0.15); outline:none; }
.form-container select option{ background:#222; color:white; }
.time-select{ display:flex; gap:10px; margin-bottom:20px; }
.time-select select{ flex:1; }
.amount-container{ display:flex; gap:10px; align-items:center; margin-bottom:20px; }
.amount-container input{ flex:1; padding:12px; border-radius:10px; border:none; background: rgba(255,255,255,0.1); color:white; font-weight:600; }
.amount-container button{ background:#00c6ff; color:#000; padding:10px 18px; border:none; border-radius:10px; font-weight:600; cursor:pointer; transition:0.3s; }
.amount-container button:hover{ background:#0044ff; color:white; }
button.submit-btn{ width:100%; padding:14px; border:none; border-radius:12px; font-size:16px; font-weight:600; cursor:pointer; background: linear-gradient(135deg,#0044ff,#00c6ff); color:white; transition:0.3s; }
button.submit-btn:hover{ background: linear-gradient(135deg,#002699,#0044ff); }
@media(max-width:768px){ .time-select{ flex-direction: column; } }
</style>

<script>
function goBack(){ window.history.back(); }

function updateAmount(){
    const period = document.getElementById('period').value;
    let amount = 149;
    if(period=='45 min') amount = 249;
    if(period=='1 hour') amount = 399;
    document.getElementById('amount').value = '₹'+amount;
}

function openPaymentModal() {
    document.getElementById("paymentModal").style.display = "block";
}

function closePaymentModal() {
    document.getElementById("paymentModal").style.display = "none";
}

</script>
<script src="js/smart-voice-system.js"></script>
</head>

<body>
<div class="overlay"></div>
<div class="wrapper">

<a class="back-btn" href="<?php 
echo ($_SESSION['role'] === 'learner') 
    ? 'learner_home.php' 
    : 'user_home.php'; ?>">Back</a>

<div class="form-container">
    <h2>Live Class</h2>

    <?php if($message){ echo '<div class="message">'.$message.'</div>'; } ?>

    <form method="post">
        <input type="hidden" name="payment_done" value="<?php echo $_SESSION['payment_done'] ? 1 : 0; ?>">

        <label>Select Date</label>
        <input type="date" name="session_date" required
        value="<?php echo htmlspecialchars($prefill['session_date'] ?? ''); ?>">

        <label>Select Time</label>
        <div class="time-select">
            <select name="hour" required>
                <?php for($i=1;$i<=12;$i++){
                    $sel = (isset($prefill['hour']) && $prefill['hour']==$i) ? 'selected' : '';
                    echo "<option $sel>$i</option>";
                } ?>
            </select>

            <select name="minute" required>
                <?php
                for($m=0;$m<=59;$m++){
                    $val = str_pad($m,2,"0",STR_PAD_LEFT);
                    $sel = (isset($prefill['minute']) && $prefill['minute']==$val) ? 'selected' : '';
                    echo "<option value='$val' $sel>$val</option>";
                }
                ?>
            </select>

            <select name="ampm" required>
                <?php
                $amps = ['AM','PM'];
                foreach($amps as $a){
                    $sel = (isset($prefill['ampm']) && $prefill['ampm']==$a) ? 'selected' : '';
                    echo "<option $sel>$a</option>";
                }
                ?>
            </select>
        </div>

        <label>Select Time Period</label>
        <select name="period" id="period" onchange="updateAmount()" required>
            <?php
            $periods = ['30 min'=>149,'45 min'=>249,'1 hour'=>399];
            foreach($periods as $p=>$amt){
                $sel = (isset($prefill['period']) && $prefill['period']==$p) ? 'selected' : '';
                echo "<option value='$p' $sel>$p</option>";
            }
            ?>
        </select>

        <label>Amount</label>
<div class="amount-container">
    <input type="text" id="amount" name="amount" readonly
    value="₹<?php echo isset($prefill['period']) ? $periods[$prefill['period']] : '149'; ?>">
    <button type="button" id="rzp-button1">Pay Now</button>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
var options = {
    "key": "rzp_test_SLEbRgnOW8LP57", // Enter the Key ID generated from the Dashboard
    "amount": "1*100", // Amount is in currency subunits.
    "currency": "INR",
    "name": "Acme Corp", //your business name
    "description": "Test Transaction",
    "image": "https://example.com/your_logo",
    //"order_id": "order_9A33XWu170gUtm", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
    "handler": function (response){
        //alert(response.razorpay_payment_id);
        //alert(response.razorpay_order_id);
        //alert(response.razorpay_signature)
       alert("Payment successful!");

// Set hidden input value to 1
document.querySelector('input[name="payment_done"]').value = "1";

// Enable Apply button
document.querySelector('.submit-btn').disabled = false;
    },
    "prefill": { //We recommend using the prefill parameter to auto-fill customer's contact information, especially their phone number
        "name": "ABC", //your customer's name
        "email": "abc@gmail.com", 
        "contact": "1234567890"  //Provide the customer's phone number for better conversion rates 
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
};
var rzp1 = new Razorpay(options);
rzp1.on('payment.failed', function (response){
        //alert(response.error.code);
        //alert(response.error.description);
        //alert(response.error.source);
        //alert(response.error.step);
        //alert(response.error.reason);
        //alert(response.error.metadata.order_id);
        //alert(response.error.metadata.payment_id);
        alert("payment failed");
});
document.getElementById('rzp-button1').onclick = function(e){
    rzp1.open();
    e.preventDefault();
}
</script>
</div>

        <button type="submit" name="apply" class="submit-btn"
        <?php if(!$_SESSION['payment_done']) echo 'disabled'; ?>>
        Apply
        </button>
    </form>
</div>

</div>
<!-- Payment Modal -->
<div id="paymentModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:#00000090; z-index:999;">

  <div style="background:white; width:400px; margin:100px auto; padding:20px; border-radius:10px; text-align:center;">
    
    <h3>Select Payment Method</h3>

   <button onclick="startPayment()" style="width:100%; padding:12px;">
Pay Using Razorpay
</button>

    <br><br>
    <button onclick="closePaymentModal()">Cancel</button>

  </div>
</div>

</body>
</html>
