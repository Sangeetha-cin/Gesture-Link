<?php
include("config.php"); 

// Handle admin reply
if(isset($_POST['reply_btn'])){
    $reply = mysqli_real_escape_string($conn, $_POST['reply']);
    $fid = intval($_POST['fid']);

    $update = mysqli_query($conn, "UPDATE feedback SET reply='$reply' WHERE id='$fid'");

    header("Location: admin_view_feedback.php?success=1");
    exit();
}

// Fetch all feedback with user details
$q = mysqli_query($conn, "
    SELECT feedback.*, users.name, users.email 
    FROM feedback 
    JOIN users ON feedback.user_id = users.id
    ORDER BY feedback.id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Feedback & Support - GestureLink</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#f5f7fb;
    color:#333;
}

/* ===== HEADER ===== */
.header{
    background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
    padding:20px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    color:white;
    box-shadow:0 4px 20px rgba(0,0,0,0.2);
}

.header h1{
    font-size:20px;
    font-weight:600;
    letter-spacing:1px;
}

.home-btn{
    background:white;
    color:#203a43;
    padding:8px 20px;
    border-radius:30px;
    text-decoration:none;
    font-weight:600;
    transition:0.3s ease;
}

.home-btn:hover{
    background:#eaeaea;
    transform:translateY(-2px);
}

/* ===== MAIN CARD ===== */
.container{
    width:95%;
    max-width:1250px;
    margin:40px auto;
    background:white;
    padding:40px;
    border-radius:16px;
    box-shadow:0 15px 40px rgba(0,0,0,0.08);
}

.container h2{
    margin-bottom:30px;
    font-size:24px;
    font-weight:600;
    color:#203a43;
    position:relative;
}

.container h2::after{
    content:"";
    width:60px;
    height:4px;
    background:#2c5364;
    position:absolute;
    bottom:-10px;
    left:0;
    border-radius:10px;
}

/* ===== SUCCESS MESSAGE ===== */
.success-msg{
    background:#e6f9f0;
    color:#0f5132;
    padding:14px;
    border-left:5px solid #198754;
    border-radius:8px;
    margin-bottom:25px;
    font-weight:500;
}

/* ===== TABLE ===== */
table{
    width:100%;
    border-collapse:separate;
    border-spacing:0 12px;
}

th{
    text-align:left;
    padding:14px;
    font-size:13px;
    text-transform:uppercase;
    letter-spacing:1px;
    color:#6c757d;
}

td{
    background:white;
    padding:18px;
    font-size:14px;
    border-top:1px solid #f0f0f0;
    border-bottom:1px solid #f0f0f0;
}

tr{
    box-shadow:0 6px 18px rgba(0,0,0,0.04);
    border-radius:10px;
}

tr td:first-child{
    border-left:1px solid #f0f0f0;
    border-radius:10px 0 0 10px;
}

tr td:last-child{
    border-right:1px solid #f0f0f0;
    border-radius:0 10px 10px 0;
}

/* ===== USER INFO ===== */
.user-name{
    font-weight:600;
    color:#203a43;
}

.user-email{
    font-size:13px;
    color:#6c757d;
}

.date-text{
    font-size:12px;
    color:#999;
}

/* ===== MESSAGE BOX ===== */
.message-box{
    background:#f8f9fc;
    padding:12px;
    border-radius:8px;
    font-size:14px;
}

/* ===== REPLY FORM ===== */
textarea{
    width:100%;
    height:90px;
    padding:12px;
    border-radius:10px;
    border:1px solid #ddd;
    font-family:'Poppins',sans-serif;
    resize:none;
    transition:0.3s;
    margin-bottom:10px;
}

textarea:focus{
    border-color:#2c5364;
    outline:none;
    box-shadow:0 0 0 3px rgba(44,83,100,0.1);
}

.reply-btn{
    background:linear-gradient(135deg,#28a745,#218838);
    border:none;
    padding:9px 20px;
    color:white;
    border-radius:25px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}

.reply-btn:hover{
    transform:translateY(-2px);
    box-shadow:0 6px 15px rgba(0,0,0,0.1);
}

/* ===== EXISTING REPLY ===== */
.reply-text{
    background:#e9f7ef;
    padding:12px;
    border-left:4px solid #28a745;
    border-radius:8px;
    color:#155724;
}

/* ===== RESPONSIVE ===== */
@media(max-width:768px){
    table,thead,tbody,tr,th,td{
        display:block;
    }
    th{
        display:none;
    }
    tr{
        margin-bottom:20px;
    }
    td{
        border:none;
        border-bottom:1px solid #eee;
        border-radius:0 !important;
    }
}

</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<div class="header">
    <h1>GestureLink Admin Panel</h1>
    <a href="adminhome.php" class="home-btn">Home</a>
</div>

<div class="container">

<?php if(isset($_GET['success'])) { ?>
    <div class="success-msg">
        Reply sent successfully!
    </div>
<?php } ?>

<h2>User Feedback & Support</h2>

<table>
<thead>
<tr>
    <th>ID</th>
    <th>User</th>
    <th>Message</th>
    <th>Admin Reply</th>
</tr>
</thead>

<tbody>

<?php
if(mysqli_num_rows($q) > 0){
    while($row = mysqli_fetch_assoc($q)){
?>
<tr>
<td><?= $row['id']; ?></td>

<td>
    <div class="user-name"><?= $row['name']; ?></div>
    <div class="user-email"><?= $row['email']; ?></div>
    <div class="date-text"><?= $row['created_at']; ?></div>
</td>

<td>
    <div class="message-box">
        <?= nl2br($row['feedback']); ?>
    </div>
</td>

<td>
<?php if(empty($row['reply'])){ ?>
    <form method="post">
        <textarea name="reply" required placeholder="Write your professional reply..."></textarea>
        <input type="hidden" name="fid" value="<?= $row['id'] ?>">
        <button type="submit" name="reply_btn" class="reply-btn">Send Reply</button>
    </form>
<?php } else { ?>
    <div class="reply-text">
        <?= nl2br($row['reply']); ?>
    </div>
<?php } ?>
</td>

</tr>
<?php 
    }
} else {
    echo "<tr><td colspan='4' style='text-align:center;'>No feedback yet.</td></tr>";
}
?>

</tbody>
</table>

</div>

</body>
</html>