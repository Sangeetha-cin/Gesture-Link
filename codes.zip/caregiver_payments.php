<?php
session_start();
include("config.php");

/* =========================
   SECURITY – only caregiver
========================= */
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'caregiver') {
    header("Location: login.php");
    exit();
}

$caregiverId = $_SESSION['id'];

/* =========================
   FETCH TRANSFERRED PAYMENTS
========================= */
$sql = "
SELECT 
    id,
    session_date,
    session_time,
    amount,
    transferred
FROM sessions
WHERE caregiver_id = $caregiverId
  AND transferred = 1
ORDER BY session_date DESC, session_time DESC
";

$result = mysqli_query($conn, $sql);
if(!$result){
    die("Query Failed: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html>
<head>
<title>My Earnings</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<style>
body{margin:0;font-family:Poppins;background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);color:white;}
.wrapper{max-width:1100px;margin:auto;padding:40px;}
header{display:flex;justify-content:space-between;align-items:center;margin-bottom:25px;}
.back{background:#00c6ff;color:#000;padding:8px 18px;border-radius:20px;text-decoration:none;font-weight:600;}
.card{background:rgba(255,255,255,0.1);backdrop-filter:blur(6px);border-radius:16px;padding:25px;box-shadow:0 10px 30px rgba(0,0,0,.4);}
table{width:100%;border-collapse:collapse;}
th,td{padding:12px;text-align:center;}
th{background:#00c6ff;color:#000;}
tr:nth-child(even){background:rgba(255,255,255,0.05);}
.badge{padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600;}
.paid{background:#00e676;color:#000;}
.money{font-weight:600;color:#00e676;}
.profit{color:#ffb300;}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>
<div class="wrapper">

<header>
<h2>💰 My Earnings</h2>
<a href="caregiver_home.php" class="back">← Back</a>
</header>

<div class="card">
<table>
<tr>
<th>Date</th>
<th>Time</th>
<th>Total Amount (₹)</th>
<th>System Profit 10%</th>
<th>You Received (₹)</th>
<th>Status</th>
</tr>

<?php if(mysqli_num_rows($result) > 0): ?>
<?php while($row = mysqli_fetch_assoc($result)): ?>

<?php
$total  = (float)$row['amount'];
$profit = round($total * 0.10, 2);
$final  = round($total - $profit, 2);
?>

<tr>
<td><?= date("d-m-Y", strtotime($row['session_date'])) ?></td>
<td><?= date("h:i A", strtotime($row['session_time'])) ?></td>
<td><?= number_format($total,2) ?></td>
<td class="profit">-<?= number_format($profit,2) ?></td>
<td class="money"><?= number_format($final,2) ?></td>
<td><span class="badge paid">Transferred</span></td>
</tr>

<?php endwhile; ?>
<?php else: ?>
<tr>
<td colspan="6">❌ No transferred payments yet.</td>
</tr>
<?php endif; ?>

</table>
</div>

</div>
</body>
</html>
