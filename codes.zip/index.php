<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gesture Link</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700;800&display=swap" rel="stylesheet">
<script src="js/smart-voice-system.js"></script>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Poppins',sans-serif;}
body{background:#0a1f38;overflow-x:hidden;}
html{scroll-behavior:smooth;}

/* NAVBAR */
.navbar{
position:fixed;top:0;width:100%;padding:18px 60px;
display:flex;justify-content:space-between;align-items:center;
background:rgba(8,28,49,0.9);backdrop-filter:blur(12px);
box-shadow:0 4px 25px rgba(0,0,0,0.4);z-index:1000;
}
.logo{display:flex;align-items:center;font-size:24px;font-weight:700;color:#fff;}
.logo img{height:45px;margin-right:10px;}
.navbar ul{display:flex;align-items:center;list-style:none;gap:28px;}
.navbar ul li a{
text-decoration:none;color:#fff;font-size:15px;font-weight:500;
position:relative;transition:0.3s;
}
.navbar ul li a::after{
content:"";position:absolute;width:0;height:2px;left:0;bottom:-5px;
background:#00c3ff;transition:0.3s;
}
.navbar ul li a:hover::after{width:100%;}
#voiceBtn{
background:linear-gradient(135deg,#0a66ff,#00c3ff);
color:#fff;border:none;padding:9px 18px;border-radius:25px;
font-size:14px;font-weight:600;cursor:pointer;transition:0.3s;
}
#voiceBtn:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,0.3);}

/* HERO */
.hero{
height:100vh;background:url("assets/bck.jpg") no-repeat center/cover;
display:flex;justify-content:center;align-items:center;text-align:center;
position:relative;padding-top:80px;
}
.hero::before{
content:"";position:absolute;inset:0;
background:linear-gradient(to right,rgba(6,35,69,0.9),rgba(6,35,69,0.7));
}
.hero-content{position:relative;color:#fff;max-width:850px;}
.hero h1{font-size:60px;font-weight:800;margin-bottom:20px;}
.hero p{font-size:20px;margin-bottom:35px;opacity:0.9;}
.btn-primary{
display:inline-block;padding:15px 45px;background:#fff;color:#09243e;
font-weight:600;border-radius:40px;text-decoration:none;transition:0.3s;
}
.btn-primary:hover{background:#00c3ff;color:#fff;}

/* FEATURES */
.features{padding:120px 80px;background:linear-gradient(to bottom,#f4f9ff,#e8f3ff);text-align:center;}
.features h2{font-size:38px;margin-bottom:70px;color:#0a1f38;}
.feature-cards{display:flex;justify-content:center;gap:40px;flex-wrap:wrap;}
.card{
width:300px;background:#fff;padding:40px 30px;border-radius:20px;
box-shadow:0 10px 35px rgba(0,0,0,0.08);transition:0.4s;
}
.card:hover{transform:translateY(-12px);box-shadow:0 20px 45px rgba(0,0,0,0.15);}
.card h3{color:#0a66ff;margin-bottom:18px;}
.card p{font-size:15px;color:#444;line-height:1.7;}

/* BANNER */
.slide3{padding:140px 60px;background:linear-gradient(135deg,#0a1f38,#123c66);text-align:center;color:#fff;}
.slide3-content{max-width:800px;margin:auto;}
.slide3 h2{font-size:42px;margin-bottom:25px;}
.slide3 p{font-size:19px;line-height:1.8;opacity:0.9;}

/* HOW IT WORKS */
.slide4{padding:120px 60px;background:#fff;text-align:center;}
.slide4 h2{font-size:38px;margin-bottom:70px;color:#0a1f38;}
.steps-container{display:flex;justify-content:center;gap:40px;flex-wrap:wrap;}
.step-box{
width:300px;padding:40px;border-radius:18px;background:#f4f9ff;
box-shadow:0 8px 25px rgba(0,0,0,0.08);transition:0.4s;
}
.step-box:hover{transform:translateY(-12px);box-shadow:0 18px 40px rgba(0,0,0,0.15);}
.step-box h3{margin-bottom:15px;color:#0a66ff;}
.step-box p{font-size:15px;color:#444;line-height:1.7;}

/* TESTIMONIALS */
.testimonials{
padding:120px 60px;background:#f8fbff;text-align:center;
}
.testimonials h2{
font-size:38px;margin-bottom:60px;color:#0a1f38;
}
.testimonial-container{
display:flex;justify-content:center;gap:40px;flex-wrap:wrap;
}
.testimonial{
width:320px;background:#fff;padding:35px;border-radius:20px;
box-shadow:0 10px 30px rgba(0,0,0,0.08);
}
.testimonial p{
font-size:15px;color:#555;line-height:1.7;margin-bottom:15px;
}
.testimonial h4{
color:#0a66ff;font-size:16px;
}

/* CALL TO ACTION */
.cta{
padding:120px 60px;
background:linear-gradient(135deg,#0a66ff,#00c3ff);
text-align:center;color:#fff;
}
.cta h2{
font-size:40px;margin-bottom:25px;
}
.cta a{
display:inline-block;padding:15px 45px;background:#fff;
color:#0a1f38;font-weight:600;border-radius:40px;text-decoration:none;
transition:0.3s;
}
.cta a:hover{background:#0a1f38;color:#fff;}

/* FOOTER */
footer{
background:#06192c;color:#bbb;padding:60px 80px;
}
.footer-container{
display:flex;justify-content:space-between;flex-wrap:wrap;
}
.footer-col{
width:220px;margin-bottom:30px;
}
.footer-col h4{
color:#fff;margin-bottom:20px;
}
.footer-col ul{
list-style:none;
}
.footer-col ul li{
margin-bottom:10px;
}
.footer-col ul li a{
text-decoration:none;color:#bbb;font-size:14px;
}
.footer-bottom{
text-align:center;margin-top:30px;font-size:13px;color:#888;
}
</style>
</head>

<body>

<div class="navbar">
<div class="logo">
<img src="assets/logoo.jpg" alt="Logo">
Gesture Link
</div>
<ul>
<li><a href="index.php">HOME</a></li>
<li><a href="register.php">REGISTRATION</a></li>
<li><a href="login.php">LOGIN</a></li>
<li><a href="about.php">ABOUT</a></li>
<li><button id="voiceBtn" onclick="toggleVoice()">🔊 Voice Off</button></li>
</ul>
</div>

<section class="hero">
<div class="hero-content">
<h1>Connect Beyond Words</h1>
<p>Gesture Link bridges communication between speech and sign language users through intelligent technology.</p>
<a class="btn-primary" href="#">Get Started</a>
</div>
</section>

<section class="features">
<h2>Our Features</h2>
<div class="feature-cards">
<div class="card"><h3>Live Gesture Translation</h3><p>Instant voice-to-sign and sign-to-text conversion.</p></div>
<div class="card"><h3>Accessible UI</h3><p>Designed for inclusive and barrier-free interaction.</p></div>
<div class="card"><h3>Multi-language Support</h3><p>AI powered translation across regional languages.</p></div>
</div>
</section>

<section class="slide3">
<div class="slide3-content">
<h2>Empowering Inclusive Communication</h2>
<p>Gesture Link removes communication barriers using AI and smart gesture recognition.</p>
</div>
</section>

<section class="slide4">
<h2>How Gesture Link Works</h2>
<div class="steps-container">
<div class="step-box"><h3>1. Register</h3><p>Create your account easily.</p></div>
<div class="step-box"><h3>2. Connect</h3><p>Start real-time communication.</p></div>
<div class="step-box"><h3>3. Interact</h3><p>Experience seamless conversations.</p></div>
</div>
</section>

<!-- NEW PROFESSIONAL SECTIONS -->

<section class="testimonials">
<h2>What Our Users Say</h2>
<div class="testimonial-container">
<div class="testimonial">
<p>"Gesture Link changed the way I communicate. It's simple and powerful."</p>
<h4>- User</h4>
</div>
<div class="testimonial">
<p>"The real-time gesture translation is incredibly accurate and helpful."</p>
<h4>- Interpreter</h4>
</div>
<div class="testimonial">
<p>"Finally, technology that truly supports accessibility."</p>
<h4>- Learner</h4>
</div>
</div>
</section>

<section class="cta">
<h2>Ready to Experience Inclusive Communication?</h2>
<a href="register.php">Join Gesture Link Today</a>
</section>

<footer>
<div class="footer-container">
<div class="footer-col">
<h4>Gesture Link</h4>
<p>Bridging communication gaps with intelligent technology.</p>
</div>
<div class="footer-col">
<h4>Quick Links</h4>
<ul>
<li><a href="index.php">Home</a></li>
<li><a href="register.php">Register</a></li>
<li><a href="login.php">Login</a></li>
</ul>
</div>
<div class="footer-col">
<h4>Support</h4>
<ul>
<li><a href="#">Help Center</a></li>
<li><a href="#">Privacy Policy</a></li>
<li><a href="#">Terms</a></li>
</ul>
</div>
</div>
<div class="footer-bottom">
© 2026 Gesture Link — Connecting People With Technology
</div>
</footer>

</body>
</html>