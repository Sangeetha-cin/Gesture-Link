<?php
session_start();
include("config.php");

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'learner') {
    echo "<script>alert('Please login as Learner first!'); window.location.href='login.php';</script>";
    exit();
}

date_default_timezone_set("Asia/Kolkata");
$userId = $_SESSION['id'];

$sql = "SELECT * FROM applications 
        WHERE user_id = ? 
        AND assigned_status = 1
        AND session_date = CURDATE()
        ORDER BY session_time ASC
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$session = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Learner Dashboard</title>

<style>

/* ===== GLOBAL ===== */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:#f1f5f9;
    color:#1e293b;
}

/* ===== NAVBAR ===== */

.navbar{
    background:#0b1f3a;
    padding:20px 60px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.logo{
    color:white;
    font-size:20px;
    font-weight:700;
    letter-spacing:1px;
}

.nav-links{
    display:flex;
    gap:25px;
}

.nav-links a{
    color:#cbd5e1;
    text-decoration:none;
    font-size:14px;
    font-weight:600;
    transition:0.3s;
}

.nav-links a:hover{
    color:#ffffff;
}

/* ===== HERO ===== */

.hero{
    background:linear-gradient(135deg,#0b1f3a,#142f5f);
    color:white;
    padding:90px 20px 110px;
    text-align:center;
}

.hero h1{
    font-size:44px;
    margin-bottom:15px;
}

.hero p{
    max-width:750px;
    margin:auto;
    font-size:17px;
    line-height:1.7;
    opacity:0.9;
}

/* ===== MAIN WRAPPER ===== */

.wrapper{
    width:92%;
    max-width:1200px;
    margin:-70px auto 80px;
}

/* ===== FEATURE GRID ===== */

.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:30px;
}

.card{
    background:white;
    padding:35px;
    border-radius:16px;
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
    transition:0.3s;
    border-top:5px solid #0b1f3a;
}

.card:hover{
    transform:translateY(-6px);
}

.card h2{
    margin-bottom:15px;
    color:#0b1f3a;
}

.card p{
    font-size:14px;
    line-height:1.6;
}

/* ===== BUTTONS ===== */

.primary-btn{
    display:inline-block;
    margin-top:20px;
    background:#0b1f3a;
    color:white;
    padding:13px 26px;
    border-radius:8px;
    text-decoration:none;
    font-weight:600;
    transition:0.3s;
}

.primary-btn:hover{
    background:#162f5f;
}

.success-btn{
    background:linear-gradient(45deg,#0f9d58,#00c853);
    padding:16px 30px;
    border-radius:8px;
    color:white;
    font-weight:700;
    text-decoration:none;
    display:inline-block;
}

.secondary-btn{
    background:#64748b;
    padding:16px 30px;
    border-radius:8px;
    color:white;
    border:none;
    font-weight:600;
}

/* ===== SESSION SECTION ===== */

.session-box{
    margin-top:50px;
    background:white;
    padding:40px;
    border-radius:16px;
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
    text-align:center;
}

.session-box h3{
    margin-bottom:20px;
    color:#0b1f3a;
}

/* ===== EXTRA SECTION ===== */

.highlight-section{
    margin-top:60px;
    background:linear-gradient(135deg,#0b1f3a,#1d3d75);
    padding:50px;
    border-radius:18px;
    color:white;
    text-align:center;
}

.highlight-section h2{
    margin-bottom:15px;
}

.highlight-section p{
    max-width:800px;
    margin:auto;
    line-height:1.7;
    opacity:0.95;
}

/* ===== FOOTER ===== */

.footer{
    background:#0b1f3a;
    color:#cbd5e1;
    text-align:center;
    padding:25px;
    font-size:14px;
}

/* ===== RESPONSIVE ===== */

@media(max-width:768px){

.hero h1{
    font-size:30px;
}

.navbar{
    flex-direction:column;
    gap:15px;
}

.nav-links{
    flex-direction:column;
    align-items:center;
}

}

</style>

<script src="js/smart-voice-system.js"></script>
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
<div class="logo">Gesture Learning</div>
<div class="nav-links">
<a href="learner_home.php">HOME</a>
<a href="learn_gestures.php">LEARN</a>
<a href="learner_quiz.php">QUIZ</a>
<a href="apply_live_class.php">LIVE CLASS</a>
<a href="logout.php">LOG OUT</a>
</div>
</div>

<!-- HERO -->
<div class="hero">
<h1>Empower Yourself with the Language of Hands</h1>
<p>
A professional gesture learning system designed to promote accessibility,
inclusive communication, and confident real-world interaction.
</p>
</div>

<div class="wrapper">

<!-- FEATURE CARDS -->
<div class="grid">

<div class="card">
<h2>Welcome Back 👋</h2>
<p>
Continue your learning journey with structured lessons,
interactive practice, and real-time communication sessions.
</p>
<a href="learn_gestures.php" class="primary-btn">Start Learning</a>
</div>

<div class="card">
<h2>Why Sign Language?</h2>
<p>
Sign language bridges communication gaps, supports accessibility,
and creates a more inclusive society for everyone.
</p>
</div>

<div class="card">
<h2>What You Will Master</h2>
<p>
✔ Gesture Recognition<br>
✔ Meaning & Interpretation<br>
✔ Visual Communication Skills<br>
✔ Live Conversation Practice
</p>
</div>

</div>

<!-- LIVE SESSION -->
<div class="session-box">
<h3>Today’s Live Session</h3>

<?php
$now = time();

if($session):

$sessionStart = strtotime($session['session_date'].' '.$session['session_time']);
$callStatus = $session['call_status'] ?? '';
$callRoom = $session['call_room'] ?? '';
?>

<?php if($callStatus === 'started' && !empty($callRoom)): ?>

<a href="<?= htmlspecialchars($callRoom) ?>" target="_blank" class="success-btn">
Join Video Call
</a>

<?php elseif($now < $sessionStart): ?>

<button class="secondary-btn" disabled>
Upcoming Call at <?= date("h:i A", $sessionStart) ?>
</button>

<?php else: ?>

<button class="secondary-btn" disabled>
Waiting for caregiver to start the call…
</button>

<?php endif; ?>

<?php else: ?>

<p>No scheduled live sessions for today.</p>

<?php endif; ?>

</div>

<!-- EXTRA BEAUTIFUL SECTION -->
<div class="highlight-section">
<h2>Build Confidence. Communicate Freely.</h2>
<p>
Our platform is designed to support learners through guided gesture training,
interactive quizzes, and live caregiver sessions — ensuring practical learning
that builds confidence in real-life communication.
</p>
</div>

</div>

<div class="footer">
© 2026 Gesture Learning System — Learn. Communicate. Connect.
</div>

<script>
setInterval(()=>{
    location.reload();
},10000);
</script>

</body>
</html>