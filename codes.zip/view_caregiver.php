<?php
session_start();
include("config.php");

// Handle Accept / Reject actions safely
if (isset($_GET['action']) && isset($_GET['id'])) {

    ob_clean(); // prevent header issues

    $id = intval($_GET['id']);
    $action = $_GET['action'];

    if ($action == 'accept') {
        $update = mysqli_query($conn, "UPDATE users SET status='accepted' WHERE id=$id");
    } elseif ($action == 'reject') {
        $update = mysqli_query($conn, "UPDATE users SET status='rejected' WHERE id=$id");
    }

    if (!$update) {
        die("Database update failed: " . mysqli_error($conn));
    }

    header("Location: http://localhost/GestureLinkProject/view_caregiver.php");
    exit();
}

// Fetch caregivers
$result = mysqli_query($conn, "SELECT * FROM users WHERE role='caregiver'");
if (!$result) {
    die("Database query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Caregivers - GestureLink</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>

body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background: #f4f7fc;
}

/* Top Header */
.admin-header {
    background: #0a1f44;
    color: white;
    padding: 18px 40px;
    font-size: 20px;
    font-weight: 600;
    letter-spacing: 1px;
}

.home-btn {
    float: right;
    background: white;
    color: #0a1f44;
    padding: 8px 18px;
    border-radius: 25px;
    text-decoration: none;
    font-weight: 600;
    transition: 0.3s;
}

.home-btn:hover {
    background: #e6e6e6;
    transform: scale(1.05);
}

/* Main Card */
.container {
    width: 95%;
    max-width: 1200px;
    margin: 40px auto;
    background: white;
    padding: 40px;
    border-radius: 15px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.08);
}

.container h2 {
    margin-bottom: 25px;
    font-size: 26px;
    color: #0a1f44;
    border-left: 5px solid #0a1f44;
    padding-left: 15px;
}

/* Table */
table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #0a1f44;
    color: white;
    padding: 14px;
    text-transform: uppercase;
    font-size: 13px;
    letter-spacing: 1px;
}

td {
    padding: 14px;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}

tr:hover {
    background: #f1f5fb;
}

/* Status Badges */
.status-pending {
    background: #fff3cd;
    color: #856404;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    display: inline-block;
}

.status-accepted {
    background: #d4edda;
    color: #155724;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    display: inline-block;
}

.status-rejected {
    background: #f8d7da;
    color: #721c24;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    display: inline-block;
}

/* Buttons */
.button {
    text-decoration: none;
    padding: 7px 15px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    margin-right: 5px;
    transition: 0.3s;
}

.accept {
    background: #28a745;
    color: white;
}

.accept:hover {
    background: #218838;
}

.reject {
    background: #dc3545;
    color: white;
}

.reject:hover {
    background: #c82333;
}

</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<div class="admin-header">
    GestureLink Admin Dashboard
    <a href="adminhome.php" class="home-btn">Back to dashboard</a>
</div>

<div class="container">
<h2>Registered Caregivers</h2>

<table>
<tr>
    <th>ID</th>
    <th>Caregiver Name</th>
    <th>Email</th>
    <th>Status</th>
    <th>Login Count</th>
    <th>Actions</th>
</tr>

<?php
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {

        $status_class = "status-" . strtolower($row['status']);

        echo "<tr>";
        echo "<td>".$row['id']."</td>";
        echo "<td>".$row['name']."</td>";
        echo "<td>".$row['email']."</td>";
        echo "<td><span class='$status_class'>".$row['status']."</span></td>";
        echo "<td>".$row['login_count']."</td>";
        echo "<td>
                <a class='button accept' href='?action=accept&id=".$row['id']."'>Accept</a>
                <a class='button reject' href='?action=reject&id=".$row['id']."'>Reject</a>
              </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='6' style='text-align:center;'>No caregivers found.</td></tr>";
}
?>
</table>
</div>

</body>
</html>