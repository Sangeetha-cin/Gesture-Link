<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About | GestureLink</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f7f7f7;
        }

        /* Background image section */
        .about-bg {
            width: 100%;
            height: 300px;
            background-image: url("assets/about.webp");
            background-size: cover;
            background-position: center;
            margin-bottom: 0;
        }

        .about-container {
            width: 90%;
            max-width: 1100px;
            margin: 0 auto 50px auto;
            background: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0,0,0,0.1);
            position: relative;
            top: -40px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 32px;
        }

        p {
            color: #555;
            line-height: 1.7;
            font-size: 17px;
        }

        .highlight {
            color: #0066cc;
            font-weight: bold;
        }

        /* Make first paragraph clickable */
        #redirectPara {
            cursor: pointer;
        }

        #redirectPara:hover {
            color: #0066cc;
            text-decoration: underline;
        }

        .team-section {
            margin-top: 40px;
        }

        .team-heading {
            font-size: 26px;
            color: #333;
            margin-bottom: 10px;
        }

        .footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            background: #222;
            color: #fff;
        }
    </style>

    <script>
        function goToHome() {
            window.location.href = "index.php";
        }
    </script>
    <script src="js/smart-voice-system.js"></script>

</head>

<body>

    <!-- Background Image -->
    <div class="about-bg"></div>

    <div class="about-container">
        <h1>ABOUT</h1>

        <!-- CLICKABLE PARAGRAPH -->
        <p id="redirectPara" onclick="goToHome()">
            <span class="highlight">GestureLink</span> 
        </p>

        <p>
            The system bridges the gap between sign language users and non-sign language speakers. 
            GestureLink enables interpreters to upload high-quality gestures in image or video formats, 
            helping learners visually understand, practice, and communicate effectively.
        </p>

        <p>
            With a large gesture library, voice-to-gesture converter, and learner-friendly interface, 
            this platform becomes a complete guide for anyone who wants to learn or use sign language.
        </p>

        <!-- All About This App -->
        <div class="team-section">
            <h2 class="team-heading">All About This Application</h2>
            <p>
                GestureLink is developed as a modern web solution to support inclusive communication.
                It focuses on accessibility, ease of learning, and meaningful interaction.
            </p>

            <p>
                ✔ Converts voice to corresponding sign gestures<br>
                ✔ Converts visual gesture inputs into readable meaning<br>
                ✔ Allows interpreters to upload and manage gestures<br>
                ✔ Provides an interactive library for learners<br>
                ✔ Supports GIFs, images, and video gestures<br>
                ✔ Helps specially-abled individuals communicate with confidence<br>
                ✔ Built with a focus on simplicity, accuracy, and accessibility<br>
            </p>

            <p>
                Whether you're a beginner or an experienced interpreter, GestureLink offers tools to 
                enhance your learning, practice, and communication experience.
            </p>
        </div>

        <!-- Vision -->
        <div class="team-section">
            <h2 class="team-heading">Our Vision</h2>
            <p>
                To create a future where communication barriers do not exist and sign language becomes 
                accessible to everyone across the world.
            </p>
        </div>

        <!-- Key Features -->
        <div class="team-section">
            <h2 class="team-heading">Key Features</h2>
            <p>
                ✔ Large gesture library<br>
                ✔ Voice-to-sign conversion<br>
                ✔ Image & video gesture uploads<br>
                ✔ Accurate gesture meanings<br>
                ✔ User-friendly learning interface<br>
                ✔ Designed for all age groups<br>
                ✔ Fast and reliable performance<br>
            </p>
        </div>

        <!-- Why Choose -->
        <div class="team-section">
            <h2 class="team-heading">Why Choose GestureLink?</h2>
            <p>
                GestureLink delivers a modern and inclusive way of learning sign language. 
                It is designed to support both individuals and institutions looking to enhance 
                communication with the hearing and speech impaired community.
            </p>
        </div>

        <!-- Future Enhancements -->
        <div class="team-section">
            <h2 class="team-heading">Future Enhancements</h2>
            <p>
                ✔ AI-powered gesture recognition<br>
                ✔ Real-time sign language translation<br>
                ✔ Gesture-learning mobile application<br>
                ✔ Interactive lessons & quizzes<br>
                ✔ Community gesture-sharing platform<br>
            </p>
        </div>

        <!-- Contact Section -->
        <div class="team-section">
            <h2 class="team-heading">Contact Us</h2>
            <p>
                📞 <b>Contact Number:</b> +91 98765 43210<br>
                📧 <b>Helpline Email:</b> support@gesturelink.com
            </p>
        </div>

    </div>

    <div class="footer">
        © <?php echo date('Y'); ?> GestureLink — All Rights Reserved.
    </div>

</body>
</html>
