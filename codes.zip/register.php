<?php
include("config.php");
$success = "";
$errors = array();

if(isset($_POST['register'])){

    $name     = trim($_POST['fullname'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $role     = trim($_POST['role'] ?? '');
    $physical = isset($_POST['physical']) ? $_POST['physical'] : 'yes';

    if (empty($name)) $errors[] = "Full Name is required!";
    if (!preg_match("/^[A-Za-z\s]+$/", $name)) {
        $errors[] = "Full Name should contain only letters and spaces!";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid Email Format!";
    if (strlen($password) < 6) $errors[] = "Password must be at least 6 characters long!";
    if ($role === "user" && empty($physical)) $errors[] = "Please select your physical ability!";

    $check = mysqli_query($conn, "SELECT * FROM users WHERE email='$email'");
    if(mysqli_num_rows($check) > 0){
        $errors[] = "Email already registered!";
    }

    if(empty($errors)){
        $passHash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (name, email, password, role, physical_status)
                VALUES ('$name','$email','$passHash','$role','$physical')";
        if(mysqli_query($conn, $sql)){
            $success = "🎉 Registered successfully! You can now login.";
        } else {
            $errors[] = "Database Error: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register - Gesture Link</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Poppins",sans-serif;}

body{
    background: linear-gradient(135deg,#eaf1ff,#f8fbff);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:40px 20px;
}

/* Main Layout */
.wrapper{
    width:100%;
    max-width:1150px;
    display:flex;
    gap:60px;
    align-items:center;
    justify-content:center;
}

/* LEFT SECTION */
.info-section{
    flex:1;
    animation:fadeInLeft 1s ease;
}

.info-section h1{
    font-size:44px;
    color:#0a1f38;
    margin-bottom:20px;
    font-weight:700;
}

.info-section p{
    font-size:17px;
    color:#555;
    margin-bottom:35px;
    line-height:1.8;
}

.feature-box{
    background:white;
    padding:20px;
    margin-bottom:18px;
    border-radius:14px;
    box-shadow:0 8px 25px rgba(0,0,0,0.06);
    display:flex;
    gap:15px;
    align-items:flex-start;
    transition:0.3s ease;
}

.feature-box:hover{
    transform:translateY(-4px);
    box-shadow:0 15px 35px rgba(0,0,0,0.08);
}

.feature-box i{
    font-size:22px;
    color:#0a66ff;
    margin-top:4px;
}

.feature-box h3{
    font-size:16px;
    color:#0a66ff;
    margin-bottom:5px;
}

.feature-box p{
    font-size:14px;
    color:#555;
}

/* FORM SECTION */
.form-box{
    flex:1;
    background:white;
    padding:45px;
    border-radius:22px;
    box-shadow:0 25px 60px rgba(0,0,0,0.08);
    animation:fadeInRight 1s ease;
}

.form-box h2{
    text-align:center;
    margin-bottom:30px;
    font-size:28px;
    color:#0a1f38;
}

/* Inputs */
input, select{
    width:100%;
    padding:14px;
    margin:12px 0;
    border-radius:12px;
    border:1px solid #e0e0e0;
    font-size:15px;
    transition:0.3s;
}

input:focus, select:focus{
    border-color:#0a66ff;
    outline:none;
    box-shadow:0 0 0 3px rgba(10,102,255,0.1);
}

/* Password */
.password-box{position:relative;}
.password-box input{padding-right:45px;}
.password-box i{
    position:absolute;
    right:15px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    color:#888;
}

/* Radio */
.radio-group{
    display:flex;
    gap:20px;
    margin-top:8px;
    font-size:14px;
    color:#444;
}

/* Button */
button{
    width:100%;
    padding:15px;
    background:linear-gradient(135deg,#0a66ff,#0044cc);
    border:none;
    color:white;
    font-size:16px;
    font-weight:600;
    border-radius:12px;
    cursor:pointer;
    margin-top:15px;
    transition:0.3s;
}

button:hover{
    transform:translateY(-3px);
    box-shadow:0 15px 35px rgba(10,102,255,0.3);
}

/* Back Button */
.home-btn{
    display:block;
    text-align:center;
    width:100%;
    padding:13px;
    margin-top:12px;
    text-decoration:none;
    background:#f0f4fa;
    color:#0a1f38;
    font-weight:600;
    border-radius:12px;
    transition:0.3s;
}

.home-btn:hover{
    background:#e2ebf8;
}

/* Alerts */
.error-box{
    background:#ff4d4d;
    padding:12px;
    border-radius:10px;
    color:white;
    margin-bottom:15px;
    font-size:14px;
}

.success-box{
    background:#28a745;
    padding:12px;
    border-radius:10px;
    color:white;
    margin-bottom:15px;
    font-size:14px;
}

/* Animations */
@keyframes fadeInLeft{
    from{opacity:0; transform:translateX(-40px);}
    to{opacity:1; transform:translateX(0);}
}
@keyframes fadeInRight{
    from{opacity:0; transform:translateX(40px);}
    to{opacity:1; transform:translateX(0);}
}

@media(max-width:900px){
    .wrapper{flex-direction:column;}
}
</style>

<script>
function showPhysical(){
    let role = document.getElementById("role").value;
    let section = document.getElementById("physical-section");
    section.style.display = (role === "user") ? "block" : "none";
}

function togglePassword(){
    let pass = document.getElementById("password");
    let eye = document.getElementById("eye");
    if(pass.type === "password"){
        pass.type = "text";
        eye.classList.replace("fa-eye","fa-eye-slash");
    } else {
        pass.type = "password";
        eye.classList.replace("fa-eye-slash","fa-eye");
    }
}
</script>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<div class="wrapper">

<div class="info-section">
<h1>Join Gesture Link</h1>
<p>Create your account and experience seamless communication powered by intelligent gesture recognition technology.</p>

<div class="feature-box">
<i class="fa-solid fa-hand"></i>
<div>
<h3>Smart Gesture Recognition</h3>
<p>Advanced AI for accurate real-time gesture translation.</p>
</div>
</div>

<div class="feature-box">
<i class="fa-solid fa-users"></i>
<div>
<h3>Inclusive Communication</h3>
<p>Built for users, interpreters, learners and caregivers.</p>
</div>
</div>

<div class="feature-box">
<i class="fa-solid fa-shield-halved"></i>
<div>
<h3>Secure & Reliable</h3>
<p>Strong encryption ensures complete data protection.</p>
</div>
</div>

</div>

<div class="form-box">
<h2>Create Account</h2>

<?php if(!empty($errors)){ ?>
<div class="error-box">
<?php foreach($errors as $e){ echo "<p>$e</p>"; } ?>
</div>
<?php } ?>

<?php if(!empty($success)){ ?>
<div class="success-box"><?= $success ?></div>
<?php } ?>

<form method="POST">
<input type="text" name="fullname" placeholder="Full Name" pattern="[A-Za-z\s]+" required>
<input type="email" id="email" name="email" placeholder="Email" required>

<div class="password-box">
<input type="password" id="password" name="password" placeholder="Password (min 6 chars)" required>
<i class="fa-solid fa-eye" id="eye" onclick="togglePassword()"></i>
</div>

<select name="role" id="role" onchange="showPhysical()" required>
<option value="">Select Role</option>
<option value="user">User</option>
<option value="interpreter">Interpreter</option>
<option value="learner">Learner</option>
<option value="caregiver">CareGiver</option>
<option value="session">Session Coordinator</option>
</select>

<div id="physical-section" style="display:none;">
<label>Are you physically abled?</label>
<div class="radio-group">
<label><input type="radio" name="physical" value="yes"> Yes</label>
<label><input type="radio" name="physical" value="no"> No</label>
</div>
</div>

<button type="submit" name="register">Register</button>
<a href="index.php" class="home-btn">Back</a>
</form>

</div>
</div>

</body>
</html>