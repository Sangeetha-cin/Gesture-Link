<?php
session_start();
include("config.php");

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'interpreter') {
    header("Location: login.php");
    exit();
}

$msg = "";
$error = "";

/* SUCCESS MESSAGE AFTER REDIRECT */
if (isset($_SESSION['success_msg'])) {
    $msg = $_SESSION['success_msg'];
    unset($_SESSION['success_msg']);
}

/* UPLOAD DIR */
$uploadDir = "gestures/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

/* LEVEL SELECTION (POST + GET SAFE) */
$viewLevel = isset($_POST['view_level']) ? (int)$_POST['view_level'] : 1;


/* ADD QUIZ */
if (isset($_POST['add_quiz'])) {

    $opt1 = $_POST['option1'];
    $opt2 = $_POST['option2'];
    $opt3 = $_POST['option3'];
    $opt4 = $_POST['option4'];
    $correct = $_POST['correct_option'];
    $level = $_POST['level'];

    /* LIMIT CHECK */
    $countRes = mysqli_query($conn,
        "SELECT COUNT(*) FROM quiz_questions WHERE level='$level'");
    $levelCount = mysqli_fetch_row($countRes)[0];

    if ($levelCount >= 10) {
        $error = "❌ Level $level already has 10 questions (maximum allowed)";
        $viewLevel = $level;
    } else {

        $fileName   = time() . "_" . basename($_FILES['gesture']['name']);
        $targetPath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['gesture']['tmp_name'], $targetPath)) {

            mysqli_query($conn,
            "INSERT INTO quiz_questions
            (question, option1, option2, option3, option4, correct_option, level)
            VALUES
            ('$targetPath','$opt1','$opt2','$opt3','$opt4','$correct','$level')");

            $_SESSION['success_msg'] = "✅ Quiz added successfully to Level $level!";
            header("Location: interpreter_quiz.php?level=$level#questions");

            exit();

        } else {
            $error = "❌ Upload failed. Check folder permissions.";
        }
    }
}

/* DELETE QUIZ */
if (isset($_GET['delete'])) {
    $delId = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM quiz_questions WHERE id='$delId'");
    $_SESSION['success_msg'] = "🗑 Question deleted successfully!";
    header("Location: interpreter_quiz.php?level=$viewLevel#questions");

    exit();
}

/* STATS */
$totalQuiz = mysqli_fetch_row(
    mysqli_query($conn,"SELECT COUNT(*) FROM quiz_questions")
)[0];

$levelQuiz = mysqli_fetch_row(
    mysqli_query($conn,"SELECT COUNT(*) FROM quiz_questions WHERE level='$viewLevel'")
)[0];

/* FETCH QUIZ */
$quizList = mysqli_query($conn,
"SELECT * FROM quiz_questions WHERE level='$viewLevel' ORDER BY id ASC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Interpreter Quiz Panel</title>

<style>
*{box-sizing:border-box;font-family:Poppins,sans-serif}
body{
    margin:0;
    min-height:100vh;
    background:
        linear-gradient(rgba(0,0,0,0.45),rgba(0,0,0,0.45)),
        url("assets/quiz.webp") center/cover no-repeat fixed;
    color:#1f2937;
}
.container{max-width:1200px;margin:auto;padding:30px}
.header{margin-bottom:25px}
.header h1{margin:0;color:#fff}
.header p{margin:0;color:#e5e7eb}
.back-btn{
    position:fixed;
    top:20px;
    left:20px;
    background:#fff;
    color:#1e40af;
    text-decoration:none;
    padding:10px 16px;
    border-radius:10px;
    font-weight:600;
    box-shadow:0 6px 18px rgba(0,0,0,0.2);
    z-index:1000;
}
.grid{display:grid;grid-template-columns:2fr 1fr;gap:30px}
.card{
    background:rgba(255,255,255,0.95);
    border-radius:16px;
    padding:22px;
    box-shadow:0 15px 35px rgba(0,0,0,0.2);
}
input,select,button{
    width:100%;
    padding:12px;
    margin:8px 0;
    border-radius:8px;
    border:1px solid #c7d2fe;
}
button{
    background:#2563eb;
    color:#fff;
    border:none;
    font-weight:600;
    cursor:pointer;
}
button:hover{background:#1e40af}
.msg{text-align:center;color:#16a34a;font-weight:600}
.err{text-align:center;color:#dc2626;font-weight:600}
.sidebar h3{margin-top:0;color:#1e40af}
.stat{background:#eef2ff;padding:14px;border-radius:12px;margin-bottom:12px}
.stat b{font-size:22px;color:#4338ca}
.tip{background:#f8fafc;padding:12px;border-radius:10px;margin-bottom:10px;font-size:14px}
.section{margin-top:40px}
.section h2{color:#fff}
.quiz-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
    gap:20px;
}
.quiz-card{
    background:#fff;
    padding:16px;
    border-radius:14px;
    box-shadow:0 10px 25px rgba(0,0,0,0.15);
}
video,audio{width:100%;border-radius:10px;margin-bottom:10px}
.option{background:#f1f5f9;padding:8px;border-radius:8px;margin:4px 0}
.correct{color:#16a34a;font-weight:600;margin-top:8px}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<a href="interpreter_home.php" class="back-btn">⬅ Back</a>

<div class="container">

<div class="header">
    <h1>Interpreter Quiz Panel</h1>
    <p>Gesture based quiz management</p>
</div>

<div class="grid">

<div class="card">
<h2>Add Quiz (Max 10 per Level)</h2>

<?php
if($msg) echo "<p class='msg'>$msg</p>";
if($error) echo "<p class='err'>$error</p>";
?>

<form method="post" enctype="multipart/form-data">
<input type="file" name="gesture" accept="video/*,audio/*" required>

<input type="text" name="option1" placeholder="Option 1" required>
<input type="text" name="option2" placeholder="Option 2" required>
<input type="text" name="option3" placeholder="Option 3" required>
<input type="text" name="option4" placeholder="Option 4" required>

<select name="correct_option" required>
<option value="">Correct Option</option>
<option value="1">Option 1</option>
<option value="2">Option 2</option>
<option value="3">Option 3</option>
<option value="4">Option 4</option>
</select>

<select name="level" required>
<option value="">Select Level</option>
<?php for($i=1;$i<=20;$i++){ ?>
<option value="<?= $i ?>">Level <?= $i ?></option>
<?php } ?>
</select>

<button name="add_quiz">Add Quiz</button>
</form>
</div>

<div class="card sidebar">
<h3>Dashboard</h3>
<div class="stat"><p>Total Questions</p><b><?= $totalQuiz ?></b></div>
<div class="stat"><p>Questions in Level <?= $viewLevel ?> / 10</p><b><?= $levelQuiz ?></b></div>
<div class="tip">✔ Max 10 questions per level</div>
<div class="tip">✔ Video supported</div>
<div class="tip">✔ Safe refresh (no duplicates)</div>
</div>

</div>
<div class="section" id="questions">
<h2>Level <?= $viewLevel ?> Questions</h2>


<form method="post" style="max-width:220px;margin-bottom:15px">
<select name="view_level" onchange="this.form.submit()">
<?php for($i=1;$i<=20;$i++){ ?>
<option value="<?= $i ?>" <?= ($viewLevel==$i)?'selected':'' ?>>Level <?= $i ?></option>
<?php } ?>
</select>
</form>

<div class="quiz-grid">
<?php $count=1; while($q=mysqli_fetch_assoc($quizList)){
$ext = pathinfo($q['question'],PATHINFO_EXTENSION);
?>
<div class="quiz-card">
<h3>Question <?= $count++; ?></h3>

<a href="interpreter_quiz.php?level=<?= $viewLevel ?>&delete=<?= $q['id'] ?>#questions"

onclick="return confirm('Are you sure you want to delete this question?')"
style="color:#dc2626;font-weight:600;float:right;margin-top:-28px;">
🗑 Delete
</a>

<?php if(in_array($ext,['mp4','webm','ogg'])){ ?>
<video controls preload="metadata">
    <source src="<?= htmlspecialchars($q['question']) ?>" type="video/mp4">
</video>
<?php } else { ?>
<audio controls>
    <source src="<?= htmlspecialchars($q['question']) ?>">
</audio>
<?php } ?>

<div class="option">1️⃣ <?= $q['option1'] ?></div>
<div class="option">2️⃣ <?= $q['option2'] ?></div>
<div class="option">3️⃣ <?= $q['option3'] ?></div>
<div class="option">4️⃣ <?= $q['option4'] ?></div>

<div class="correct">✔ Correct: Option <?= $q['correct_option'] ?></div>
</div>
<?php } ?>
</div>
</div>

</div>
</body>
</html>
