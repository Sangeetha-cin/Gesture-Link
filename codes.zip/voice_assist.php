<?php
session_start();
include("config.php");

if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'user' && $_SESSION['role'] !== 'learner')) {
    echo "<script>alert('Unauthorized Access!'); window.location.href='login.php';</script>";
    exit();
}

$uploadMessage = "";
$gestureMeaning = "";
$gestureName = "";
$targetFile = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['video'])) {

    $targetDir = "gestures/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

    $fileName = basename($_FILES['video']['name']);
    $targetFile = $targetDir . $fileName;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    $allowed = ["mp4","mov","avi","mkv","gif","mp3"];

    if (in_array($fileType, $allowed)) {

        if (move_uploaded_file($_FILES['video']['tmp_name'], $targetFile)) {

            $fullPath = "gestures/" . $fileName;

            $query = "SELECT gesture_name, description 
                      FROM gestures 
                      WHERE filename='" . mysqli_real_escape_string($conn, $fullPath) . "' 
                      AND status='approved'";

            $result = mysqli_query($conn, $query);

            if ($result && mysqli_num_rows($result) > 0) {

                $row = mysqli_fetch_assoc($result);
                $gestureName = $row['gesture_name'];
                $gestureMeaning = $row['description'];
                $uploadMessage = "success";

            } else {

                $checkPending = mysqli_query($conn,
                    "SELECT * FROM gestures WHERE filename='" . mysqli_real_escape_string($conn,$fullPath) . "'"
                );

                if (mysqli_num_rows($checkPending) == 0) {
                    mysqli_query($conn,
                        "INSERT INTO gestures (interpreter_id, gesture_name, description, filename, status)
                         VALUES (0, '', '', '" . mysqli_real_escape_string($conn,$fullPath) . "', 'pending')"
                    );
                }

                $uploadMessage = "pending";
            }

        } else {
            $uploadMessage = "error";
        }

    } else {
        $uploadMessage = "invalid";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Gesture AI Recognition</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<style>
*{margin:0;padding:0;box-sizing:border-box;}

body{
    font-family:'Inter',sans-serif;
    background:linear-gradient(135deg,#0f172a,#1e293b,#0f172a);
    color:#f1f5f9;
    min-height:100vh;
}

/* HEADER */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:25px 60px;
}

.logo{
    font-size:22px;
    font-weight:700;
    letter-spacing:1px;
}

.logo span{
    color:#38bdf8;
}

.home-btn{
    padding:10px 24px;
    background:linear-gradient(135deg,#2563eb,#3b82f6);
    border:none;
    color:white;
    border-radius:30px;
    font-weight:600;
    text-decoration:none;
    transition:0.3s;
}

.home-btn:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(59,130,246,0.4);
}

/* HERO */
.hero{
    text-align:center;
    margin-top:40px;
}

.hero h1{
    font-size:40px;
    font-weight:800;
    background:linear-gradient(to right,#38bdf8,#6366f1);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.hero p{
    margin-top:15px;
    color:#cbd5e1;
}

/* MAIN CARD */
.main{
    max-width:1000px;
    margin:60px auto;
    background:rgba(255,255,255,0.05);
    backdrop-filter:blur(20px);
    border-radius:25px;
    padding:60px;
    box-shadow:0 30px 60px rgba(0,0,0,0.4);
}

/* UPLOAD BOX */
.upload-box{
    border:2px dashed rgba(255,255,255,0.2);
    padding:50px;
    text-align:center;
    border-radius:20px;
    transition:0.3s;
}

.upload-box:hover{
    border-color:#38bdf8;
    background:rgba(255,255,255,0.05);
}

input[type="file"]{
    margin:25px 0;
    color:white;
}

button{
    padding:14px 35px;
    border:none;
    border-radius:30px;
    background:linear-gradient(135deg,#6366f1,#8b5cf6);
    color:white;
    font-size:15px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 25px rgba(139,92,246,0.4);
}

/* ALERTS */
.alert{
    margin-top:30px;
    padding:18px;
    border-radius:12px;
    text-align:center;
    font-weight:600;
}

.success{background:rgba(16,185,129,0.2);color:#34d399;}
.pending{background:rgba(251,191,36,0.2);color:#fbbf24;}
.error{background:rgba(239,68,68,0.2);color:#f87171;}
.invalid{background:rgba(244,63,94,0.2);color:#fb7185;}

/* PREVIEW */
.preview{
    margin-top:60px;
    text-align:center;
}

video,img{
    width:70%;
    border-radius:20px;
    margin-top:25px;
    box-shadow:0 20px 40px rgba(0,0,0,0.5);
}

/* MEANING CARD */
.meaning-card{
    margin-top:30px;
    padding:30px;
    border-radius:20px;
    background:rgba(255,255,255,0.05);
    text-align:left;
    line-height:1.8;
    border:1px solid rgba(255,255,255,0.1);
}

/* FOOTER */
.footer{
    margin-top:80px;
    text-align:center;
    padding:30px;
    color:#94a3b8;
    font-size:14px;
    border-top:1px solid rgba(255,255,255,0.1);
}
.footer span{
    color:#38bdf8;
    font-weight:600;
}

@media(max-width:768px){
    .main{padding:30px;}
    video,img{width:100%;}
    .header{padding:20px;}
    .hero h1{font-size:28px;}
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<div class="header">
    <div class="logo">Gesture<span>Know</span></div>
    <a href="user_home.php" class="home-btn">Dashboard</a>
</div>

<div class="hero">
    <h1>Smart Gesture Recognition</h1>
    <p>Upload your gesture and let find meaning instantly.</p>
</div>

<div class="main">

<div class="upload-box">
<form method="POST" enctype="multipart/form-data">
    <h2>Upload Gesture File</h2>
    <input type="file" name="video" required><br>
    <button type="submit">Analyze Gesture</button>
</form>
</div>

<?php if($uploadMessage): ?>
<div class="alert <?= $uploadMessage ?>">
<?php
if($uploadMessage=="success") echo "Gesture recognized successfully.";
if($uploadMessage=="pending") echo "Gesture uploaded and awaiting admin approval.";
if($uploadMessage=="error") echo "File upload failed. Try again.";
if($uploadMessage=="invalid") echo "Invalid file type.";
?>
</div>
<?php endif; ?>

<?php if(!empty($targetFile)): ?>
<div class="preview">

<h2>Preview Result</h2>

<?php if(in_array(strtolower(pathinfo($targetFile, PATHINFO_EXTENSION)), ['gif'])): ?>
<img src="<?= htmlspecialchars($targetFile) ?>">
<?php else: ?>
<video controls>
<source src="<?= htmlspecialchars($targetFile) ?>" type="video/mp4">
</video>
<?php endif; ?>

<div class="meaning-card">
<strong>Gesture:</strong> <?= htmlspecialchars($gestureName) ?><br><br>
<strong>Meaning:</strong> <span id="meaning"></span><br><br>
<button onclick="readMeaning()">🔊 Listen</button>
</div>

</div>
<?php endif; ?>

</div>

<div class="footer">
© <?= date("Y") ?> <span>GestureAI Enterprise Platform</span> | All Rights Reserved
</div>

<script>
const fullText = "<?= addslashes($gestureMeaning) ?>";
let index = 0;
const meaningElem = document.getElementById('meaning');

function typeMeaning(){
    if(index < fullText.length){
        meaningElem.innerHTML += fullText.charAt(index);
        index++;
        setTimeout(typeMeaning, 20);
    }
}
if(fullText.length > 0){ typeMeaning(); }

function readMeaning(){
    const msg = new SpeechSynthesisUtterance(fullText);
    msg.lang = "en-US";
    window.speechSynthesis.speak(msg);
}
</script>

</body>
</html>