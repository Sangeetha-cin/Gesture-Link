<?php
session_start();
include("config.php");

if (!isset($_SESSION['id'])) {
    exit();
}

$userId = $_SESSION['id'];

$query = mysqli_query($conn, "
    SELECT gesture_id 
    FROM gestures 
    WHERE user_id='$userId'
    AND message_status='unread'
    AND status='approved'
    LIMIT 1
");

if (mysqli_num_rows($query) > 0) {
    echo "new";
} else {
    echo "no";
}
?>