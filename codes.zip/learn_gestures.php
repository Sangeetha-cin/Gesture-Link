<?php
session_start();
include("config.php");

/* ONLY LEARNER CAN ACCESS */
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'learner') {
    echo "<script>alert('Please login as Learner first!'); window.location.href='login.php';</script>";
    exit();
}

/* ===== AJAX SEARCH ===== */
if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {

    $search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';

    $query = "SELECT gesture_id, gesture_name, description, filename 
              FROM gestures 
              WHERE status='approved'
              AND gesture_name NOT IN ('meaning','unknown')";

    if (!empty($search)) {
        $query .= " AND (gesture_name LIKE '%$search%' 
                   OR description LIKE '%$search%')";
    }

    $query .= " ORDER BY uploaded_at DESC";

    $result = mysqli_query($conn,$query);

    if ($result && mysqli_num_rows($result)>0){

        while($row=mysqli_fetch_assoc($result)){

            $file=$row['filename'];
            $ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));

            echo '<div class="card">';

            if(in_array($ext,['mp4','webm','ogg'])){
                echo '<video class="media-box" controls>
                        <source src="'.$file.'" type="video/'.$ext.'">
                      </video>';
            }
            elseif(in_array($ext,['mp3','wav'])){
                echo '<audio class="media-box" controls>
                        <source src="'.$file.'" type="audio/'.$ext.'">
                      </audio>';
            }
            elseif(in_array($ext,['jpg','jpeg','png','gif','webp'])){
                echo '<img class="media-box" src="'.$file.'">';
            }
            else{
                echo '<div class="media-box">Gesture File</div>';
            }

            echo '<div class="gesture-title">'
                .htmlspecialchars($row['gesture_name'])
                .'</div>';

            echo '<div class="description">'
                .htmlspecialchars($row['description'])
                .'</div>';

            echo '</div>';
        }

    } else {
        echo "<h2 class='no-result'>No gestures found!</h2>";
    }

    exit();
}

/* ===== DEFAULT LOAD ===== */

$query = "SELECT gesture_id, gesture_name, description, filename 
          FROM gestures 
          WHERE status='approved'
          AND gesture_name NOT IN ('meaning','unknown')
          ORDER BY uploaded_at DESC";

$result = mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Learn Gestures</title>

<style>

/* RESET */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Poppins,Segoe UI,sans-serif;
}

/* BODY */

body{
    background:0 3px 12px rgba(0,0,0,0.2);
}

/* BACK BUTTON */

.home-btn{
    position:fixed;
    top:20px;
    right:25px;
    background:#0a3b7a;
    color:white;
    padding:8px 18px;
    border-radius:8px;
    text-decoration:none;
    font-size:13px;
    font-weight:600;
    box-shadow:0 3px 12px rgba(0,0,0,0.2);
}

/* HERO HEADER */

.hero{
    text-align:center;
    padding:80px 20px 60px;
    background:#0a3b7a;
    color:white;
    border-bottom-left-radius:60px;
    border-bottom-right-radius:60px;
}

.hero h1{
    font-size:52px;
    margin-bottom:15px;
}

/* SEARCH BOX */

.search-form{
    text-align:center;
    margin-top:-30px;
    margin-bottom:40px;
}

.search-form input{
    width:60%;
    max-width:650px;
    padding:15px 25px;
    border-radius:35px;
    border:none;
    box-shadow:0 4px 20px rgba(0,0,0,0.15);
    font-size:16px;
}

/* GRID CONTAINER */

.container{
    width:95%;
    margin:auto;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:25px;
    padding-bottom:60px;
}

/* CARD */

.card{
    background:white;
    padding:15px;
    border-radius:18px;
    box-shadow:0 5px 25px rgba(0,0,0,0.08);
    transition:0.3s;
    border-top:4px solid #0a3b7a;
}

.card:hover{
    transform:translateY(-6px);
}

.media-box{
    width:100%;
    height:140px;
    object-fit:contain;
    border-radius:12px;
    background:#f4f6fb;
}

/* TEXT */

.gesture-title{
    font-weight:600;
    color:#0a3b7a;
    margin-top:10px;
    text-align:center;
}

.description{
    font-size:13px;
    color:#555;
    text-align:center;
}

/* FOOTER */

.footer{
    background:#0a3b7a;
    color:white;
    text-align:center;
    padding:18px;
    font-size:13px;
}

/* NO RESULT */

.no-result{
    text-align:center;
    color:#0a3b7a;
    margin-top:50px;
}

/* RESPONSIVE */

@media(max-width:768px){

.hero h1{
    font-size:32px;
}

.search-form input{
    width:90%;
}

}

</style>

<script src="js/smart-voice-system.js"></script>

</head>

<body>

<a class="home-btn" href="learner_home.php"> HOME</a>

<div class="hero">
<h1>Learn Approved Gestures 🤟</h1>
<p>Search and practice sign language gestures</p>
</div>

<div class="search-form">
<input type="text" id="searchInput" placeholder="Search gestures...">
</div>

<div class="container" id="gestureContainer">

<?php
if($result && mysqli_num_rows($result)>0){

while($row=mysqli_fetch_assoc($result)){

$file=$row['filename'];
$ext=strtolower(pathinfo($file,PATHINFO_EXTENSION));

echo '<div class="card">';

if(in_array($ext,['mp4','webm','ogg'])){
echo '<video class="media-box" controls>
<source src="'.$file.'" type="video/'.$ext.'">
</video>';
}

elseif(in_array($ext,['mp3','wav'])){
echo '<audio class="media-box" controls>
<source src="'.$file.'" type="audio/'.$ext.'">
</audio>';
}

elseif(in_array($ext,['jpg','jpeg','png','gif','webp'])){
echo '<img class="media-box" src="'.$file.'">';
}

else{
echo '<div class="media-box">Gesture File</div>';
}

echo '<div class="gesture-title">'
.htmlspecialchars($row['gesture_name'])
.'</div>';

echo '<div class="description">'
.htmlspecialchars($row['description'])
.'</div>';

echo '</div>';
}
}
else{
echo "<h2 class='no-result'>No approved gestures found!</h2>";
}
?>

</div>

<div class="footer">
© 2026 Gesture Learning System
</div>

<script>

const searchInput=document.getElementById('searchInput');
const container=document.getElementById('gestureContainer');

searchInput.addEventListener('keyup',function(){

let query=this.value;

fetch('learn_gestures.php?ajax=1&search='+encodeURIComponent(query))
.then(res=>res.text())
.then(data=>{
container.innerHTML=data;
});

});

</script>

</body>
</html>