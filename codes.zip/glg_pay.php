<?php
session_start();
include("config.php");

// Store form details in session
$_SESSION['paid_form'] = $_GET;

$amount = $_GET['amount'] ?? 149;
?>

<!DOCTYPE html>
<html>
<head>
    <title>GLG Pay</title>
</head>
<body style="font-family:Poppins; text-align:center; margin-top:100px;">

    <h2 style="color:#00c6ff;">GLG Pay</h2>
    <p>Secure Demo Payment Gateway</p>

    <h3>Amount: ₹<?php echo $amount; ?></h3>

    <form action="payment_success.php" method="POST">
        <input type="hidden" name="amount" value="<?php echo $amount; ?>">
        <button type="submit"
        style="padding:12px 30px; background:#00c6ff; border:none; border-radius:8px; font-weight:600;">
            Pay Now
        </button>
    </form>

</body>
</html>