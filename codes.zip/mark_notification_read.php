<?php
session_start();
include("config.php");

if (!isset($_SESSION['id'])) {
    exit();
}

$userId = $_SESSION['id'];

mysqli_query($conn, "
    UPDATE gestures 
    SET message_status='read'
    WHERE user_id='$userId'
    AND message_status='unread'
    AND status='approved'
");
?>