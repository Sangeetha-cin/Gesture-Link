<?php
$file = basename($_GET['file']);
$path = __DIR__ . "/gestures/" . $file;

if (!file_exists($path)) {
    http_response_code(404);
    exit("Video not found");
}

header("Content-Type: video/mp4");
header("Content-Length: " . filesize($path));
header("Accept-Ranges: bytes");
readfile($path);
exit;
