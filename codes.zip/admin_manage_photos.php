<?php
session_start();
include("config.php");

// ONLY ADMIN CAN ACCESS
if (!isset($_SESSION['id']) || $_SESSION['role'] != 'admin') {
    echo "<script>alert('Please login as Admin first!'); window.location.href='login.php';</script>";
    exit();
}

// Handle Approve / Reject actions
if (isset($_GET['action'], $_GET['id'])) {
    $photo_id = intval($_GET['id']);
    $action   = $_GET['action'];

    if ($action === 'approve') {
        mysqli_query($conn, "UPDATE photos SET status='approved' WHERE photo_id=$photo_id");
    } elseif ($action === 'reject') {
        mysqli_query($conn, "UPDATE photos SET status='rejected' WHERE photo_id=$photo_id");
    }
}

// Fetch photos along with interpreter name
$query = mysqli_query($conn, "
    SELECT p.*, u.name AS interpreter_name 
    FROM photos p
    JOIN users u ON p.interpreter_id = u.id
    ORDER BY p.photo_id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Photos - Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #041525ff, #103547ff);
            margin: 0; 
            padding: 0; 
            color: #fff;
        }
        .container {
            width: 90%;
            margin: 40px auto;
            background: rgba(255,255,255,0.1);
            padding: 20px;
            border-radius: 15px;
            backdrop-filter: blur(8px);
        }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 12px; text-align: center; background: rgba(0,0,0,0.2); border-bottom: 1px solid rgba(255,255,255,0.2); }
        th { background: rgba(0,0,0,0.4); }
        a.action { padding: 6px 12px; border-radius: 6px; color: white; text-decoration: none; display: inline-block; }
        .approve { background: #28a745; }
        .reject  { background: #dc3545; }
        .status { padding: 6px 12px; border-radius: 8px; font-weight: bold; }
        .approved { background: #4CAF50; }
        .pending  { background: #ff9800; }
        .rejected { background: #E53935; }
        .back { display: inline-block; background: #003366; padding: 8px 15px; border-radius: 8px; text-decoration: none; color: white; margin-bottom: 15px; }
        img { width: 120px; height: auto; border-radius: 10px; }
    </style>
</head>
<body>

<div class="container">
    <a href="adminhome.php" class="back">⬅ Back to Home</a>
    <h2 style="text-align:center;">Manage Uploaded Photos</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>Photo Title</th>
            <th>Interpreter Name</th>
            <th>Preview</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>

        <?php if(mysqli_num_rows($query) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?= $row['photo_id'] ?></td>
                    <td><?= htmlspecialchars($row['title']) ?></td>
                    <td><?= htmlspecialchars($row['interpreter_name']) ?></td>
                    <td>
                        <img src="<?= htmlspecialchars($row['filename']) ?>" alt="Photo">
                    </td>
                    <td>
                        <span class="status <?= $row['status'] ?>">
                            <?= ucfirst($row['status']) ?>
                        </span>
                    </td>
                    <td>
                        <?php if($row['status'] === "pending"): ?>
                            <a href="admin_manage_photos.php?action=approve&id=<?= $row['photo_id'] ?>" class="action approve">Approve</a>
                            <a href="admin_manage_photos.php?action=reject&id=<?= $row['photo_id'] ?>" class="action reject">Reject</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">No Uploaded Photos Found!</td></tr>
        <?php endif; ?>
    </table>
</div>

</body>
</html>
