<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'interpreter') {
    exit("Unauthorized Access");
}

$interpreter = $_SESSION['fullname'];
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Interpreter AI Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>

/* ===== GLOBAL ===== */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: "Inter", sans-serif;
}

body{

    background:
    radial-gradient(circle at 15% 20%, #020617, transparent 55%),
    radial-gradient(circle at 85% 80%, #0f172a, transparent 60%),
    linear-gradient(135deg,#020617,#0f172a,#020617);

    color:white;
    min-height:100vh;
}

/* ===== NAVBAR ===== */

nav{

    display:flex;
    justify-content:space-between;
    align-items:center;

    padding:20px 70px;

    background: rgba(255,255,255,0.04);
    backdrop-filter: blur(28px);

    border-bottom:1px solid rgba(255,255,255,0.05);

    position:sticky;
    top:0;
    z-index:100;
}

.logo{
    font-size:24px;
    font-weight:700;
}

nav ul{
    display:flex;
    gap:32px;
    list-style:none;
}

nav a{

    color:#cbd5e1;
    text-decoration:none;

    font-size:14px;

    padding:8px 16px;
    border-radius:12px;

    transition:0.3s;
}

nav a:hover{
    background:rgba(255,255,255,0.08);
    color:white;
}

/* ===== HERO ===== */

.hero{
    text-align:center;
    padding:110px 20px 60px;
}

.hero h1{

    font-size:56px;
    font-weight:700;

    background: linear-gradient(90deg,#38bdf8,#818cf8,#60a5fa);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
}

.hero p{
    margin-top:18px;
    color:#94a3b8;
    font-size:17px;
}

/* ===== CARD GRID ===== */

.container{

    width:92%;
    max-width:1250px;

    margin:60px auto;

    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:32px;
}

.card{

    background: rgba(255,255,255,0.04);

    backdrop-filter: blur(35px);

    padding:42px;

    border-radius:30px;

    border:1px solid rgba(255,255,255,0.06);

    text-align:center;

    transition:0.4s;

    box-shadow:
    0 35px 80px rgba(0,0,0,0.55);
}

.card:hover{
    transform:translateY(-10px) scale(1.03);
    background:rgba(255,255,255,0.07);
}

.card h3{
    font-size:22px;
    margin-bottom:16px;
}

.card p{
    color:#94a3b8;
    font-size:14px;
    margin-bottom:26px;
}

.card a{

    display:inline-block;

    padding:13px 30px;

    background:linear-gradient(135deg,#3b82f6,#6366f1);

    border-radius:16px;

    color:white;

    text-decoration:none;

    transition:0.3s;
}

.card a:hover{
    transform:scale(1.08);
}

/* ===== FEATURE SECTION ===== */

.section{
    width:92%;
    max-width:1250px;
    margin:90px auto;
    text-align:center;
}

.section h2{
    font-size:34px;
    margin-bottom:55px;
}

.grid{

    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:30px;
}

.box{

    background:rgba(255,255,255,0.04);

    padding:26px;

    border-radius:26px;

    border:1px solid rgba(255,255,255,0.05);

    transition:0.35s;
}

.box:hover{
    transform:translateY(-8px);
}

.box img{
    width:100%;
    height:160px;
    object-fit:cover;
    border-radius:18px;
}

.title{
    margin-top:15px;
    font-size:16px;
    color:#e2e8f0;
}

/* ===== COUNTER ===== */

.counter-boxes{

    display:flex;
    justify-content:center;
    gap:55px;
    flex-wrap:wrap;
}

.counter-card{

    width:270px;

    padding:40px;

    background:rgba(255,255,255,0.04);

    border-radius:28px;

    border:1px solid rgba(255,255,255,0.05);

    text-align:center;
}

.counter{

    font-size:50px;
    font-weight:700;

    color:#60a5fa;
}

/* ===== FOOTER ===== */

footer{

    text-align:center;
    padding:40px;
    margin-top:100px;

    background:rgba(255,255,255,0.02);

    backdrop-filter:blur(35px);

    color:#64748b;
    font-size:14px;
}

</style>
<script src="js/smart-voice-system.js"></script>

</head>

<body>

<nav>

<div class="logo">Gesture Platform</div>

<ul>
<li><a href="interpreter_home.php">Home</a></li>
<li><a href="upload_gestures.php">Upload</a></li>
<li><a href="pending_meaning.php">View</a></li>
<li><a href="interpreter_quiz.php">Quiz</a></li>
<li><a href="logout.php">Logout</a></li>
</ul>

</nav>

<div class="hero">

<h1>Sign Animation Studio</h1>

<p>Welcome, <?php echo $interpreter; ?> — Build Intelligent Gesture Experience</p>

</div>

<div class="container">

<div class="card">
<h3>Upload Gesture Signs</h3>
<p>Add training gesture dataset.</p>
<a href="upload_gestures.php">Upload</a>
</div>

<div class="card">
<h3>View Gesture Library</h3>
<p>Manage your gesture knowledge base.</p>
<a href="view_content.php">View</a>
</div>

<div class="card">
<h3>Support Center</h3>
<p>Connect with platform support.</p>
<a href="#">Contact</a>
</div>

</div>

<div class="section">

<h2>Featured Resources</h2>

<div class="grid">

<div class="box">
<img src="assets/icon.png">
<div class="title">Gesture Recording Best Practice</div>
</div>

<div class="box">
<img src="assets/icon.png">
<div class="title">Lighting Optimization Guide</div>
</div>

<div class="box">
<img src="assets/icon.png">
<div class="title">Training Data Quality Tips</div>
</div>

<div class="box">
<img src="assets/icon.png">
<div class="title">Fast Upload Processing</div>
</div>

</div>
</div>

<div class="section">

<h2>Your Contribution Intelligence</h2>

<div class="counter-boxes">

<div class="counter-card">
<div class="counter" data-target="120">0</div>
<p>Gestures Added</p>
</div>

<div class="counter-card">
<div class="counter" data-target="5000">0</div>
<p>Users Assisted</p>
</div>

</div>
</div>

<footer>
© 2026 Gesture AI Platform | Interpreter Dashboard
</footer>

<script>

/* Counter Animation */

document.querySelectorAll('.counter').forEach(counter=>{

counter.innerText="0";

const update=()=>{

let target=+counter.dataset.target;
let current=+counter.innerText;

if(current<target){
counter.innerText=Math.ceil(current+target/200);
setTimeout(update,20);
}else{
counter.innerText=target;
}

};

update();

});

</script>

</body>
</html>