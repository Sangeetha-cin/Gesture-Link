<?php
session_start();
include("config.php");

// Only allow caregivers
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'caregiver') {
    header("Location: index.php");
    exit();
}

$caregiverName = $_SESSION['fullname'];

// ================= STATS =================
$completedSessions = 0;
$pendingSessions   = 0;

$sessionsTableCheck = mysqli_query($conn, "SHOW TABLES LIKE 'sessions'");
if(mysqli_num_rows($sessionsTableCheck) > 0){
    $completedSessions = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT COUNT(*) AS total 
         FROM sessions 
         WHERE caregiver_id=".$_SESSION['id']." AND status='completed'"
    ))['total'];

    $pendingSessions = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT COUNT(*) AS total 
         FROM sessions 
         WHERE caregiver_id=".$_SESSION['id']." AND status='pending'"
    ))['total'];
}

// ================= 🔔 TODAY NOTIFICATION COUNT =================
date_default_timezone_set("Asia/Kolkata");

$today = date('Y-m-d');
$todaySessionCount = 0;

$res = mysqli_query($conn,"
    SELECT COUNT(*) AS total
    FROM sessions
    WHERE caregiver_id = ".$_SESSION['id']."
     AND DATE(session_date) = '$today'

");
$row = mysqli_fetch_assoc($res);
$todaySessionCount = (int)$row['total'];

// ================= 💰 EARNINGS =================
$totalEarned = 0;
if(mysqli_num_rows($sessionsTableCheck) > 0){
    $earn = mysqli_query($conn,
        "SELECT IFNULL(SUM(amount),0) AS total 
         FROM sessions 
         WHERE caregiver_id=".$_SESSION['id']." AND status='completed'"
    );
    $totalEarned = mysqli_fetch_assoc($earn)['total'];
}
$platformCut = $totalEarned * 0.10;
$netEarned   = $totalEarned - $platformCut;
?>
<!DOCTYPE html>
<html>
<head>
<title>Caregiver Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
*{box-sizing:border-box}
body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);
    color:#fff;
}
header{
    width:100%;
    padding:18px 30px;
    background:#081a2d;
    display:flex;
    justify-content:space-between;
    align-items:center;
    position:sticky;
    top:0;
    z-index:10;
}
header h1{margin:0;font-size:22px}

.top-right{display:flex;align-items:center;gap:20px}

.notification{position:relative;font-size:22px}
.notification span{
    position:absolute;
    top:-6px;right:-8px;
    background:#ff3d00;
    font-size:12px;
    padding:2px 6px;
    border-radius:50%;
}

.logout-btn{
    background:#ff5252;
    padding:8px 18px;
    border-radius:20px;
    color:#fff;
    text-decoration:none;
    font-weight:600;
}
.logout-btn:hover{background:#d32f2f}

/* HERO */
.hero{
    width:90%;
    max-width:1100px;
    margin:40px auto;
    padding:30px;
    border-radius:20px;
    background:linear-gradient(135deg,#ff9800,#ff5722);
    box-shadow:0 12px 30px rgba(0,0,0,.4);
}

/* CARDS */
.main-content{
    width:90%;
    max-width:1100px;
    margin:40px auto;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(260px,1fr));
    gap:30px;
}
.card{
    background:rgba(255,255,255,0.12);
    padding:30px;
    border-radius:20px;
    text-align:center;
    box-shadow:0 10px 25px rgba(0,0,0,.35);
    transition:.3s;
}
.card:hover{transform:translateY(-6px)}
.card a{
    display:inline-block;
    margin-top:12px;
    padding:10px 24px;
    border-radius:25px;
    background:#00e676;
    color:#000;
    font-weight:700;
    text-decoration:none;
}

/* STATS */
.stats{
    width:90%;
    max-width:1100px;
    margin:50px auto;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:25px;
}
.stat{
    background:rgba(255,255,255,0.12);
    padding:25px;
    border-radius:18px;
    text-align:center;
}
.stat h3{margin:0;color:#ffd54f}
.stat p{font-size:28px;margin:10px 0 0;font-weight:700}

/* TODAY */
.today{
    width:90%;
    max-width:1100px;
    margin:40px auto;
    padding:30px;
    border-radius:20px;
    background:rgba(255,255,255,0.12);
}
.today li{
    list-style:none;
    background:rgba(0,0,0,0.4);
    margin-bottom:10px;
    padding:12px 15px;
    border-radius:10px;
}

/* EXTRA */
.extra{
    width:90%;
    max-width:1100px;
    margin:50px auto;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:30px;
}
.box{
    background:rgba(255,255,255,0.12);
    padding:25px;
    border-radius:20px;
}
.box h3{color:#81d4fa}

/* QUICK ACTIONS */
.actions{text-align:center;margin:40px}
.actions a{
    margin:10px;
    padding:12px 26px;
    border-radius:30px;
    background:#ffd54f;
    color:#000;
    font-weight:700;
    text-decoration:none;
}


/* FOOTER */
footer{text-align:center;padding:25px;color:#ccc}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<header>
    <h1>Welcome, <?= htmlspecialchars($caregiverName) ?></h1>
    <div class="top-right">
        <div class="notification">
            🔔
            <?php if($todaySessionCount > 0){ ?>
                <span><?= $todaySessionCount ?></span>
            <?php } ?>
        </div>
    

        <a class="logout-btn" href="logout.php">Logout</a>
    </div>
</header>

<div class="hero">
    <h2>You're Making a Difference 🌟</h2>
    <p>Every session you take changes a learner’s life.</p>
</div>

<!-- MAIN CARDS -->
<div class="main-content">
    <div class="card">
        <h2>My Schedule</h2>
        <p>View your upcoming sessions</p>
        <a href="caregiver_classes.php">Open</a>
    </div>

    <div class="card">
        <h2>My Earnings</h2>
        <p>Check transferred payments</p>
        <a href="caregiver_payments.php">View</a>
    </div>
</div>

<!-- STATS -->
<div class="stats">
    <div class="stat">
        <h3>Completed Sessions</h3>
        <p><?= $completedSessions ?></p>
    </div>
    <div class="stat">
        <h3>Pending Sessions</h3>
        <p><?= $pendingSessions ?></p>
    </div>
</div>

<!-- TODAY -->
<div class="today">
<h2>Today's Sessions</h2>
<ul>
<?php
$sql = "
SELECT s.session_time, s.status, u.name
FROM sessions s
JOIN users u ON s.learner_id = u.id
WHERE s.caregiver_id = ".$_SESSION['id']."
AND DATE(s.session_date) = '$today'


ORDER BY s.session_time
";
$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
        echo "<li>".date('h:i A',strtotime($row['session_time'])).
             " – ".htmlspecialchars($row['name']).
             " (".ucfirst($row['status']).")</li>";
    }
}else{
    echo "<li>No sessions scheduled today</li>";
}
?>
</ul>
</div>

<!-- EXTRA -->
<div class="extra">
    <div class="box">
        <h3>💰 Earnings Summary</h3>
        <p>Total Earned: ₹<?= number_format($totalEarned,2) ?></p>
        <p>Platform Fee (10%): ₹<?= number_format($platformCut,2) ?></p>
        <p><strong>You Receive: ₹<?= number_format($netEarned,2) ?></strong></p>
    </div>

    <div class="box">
        <h3>🌟 Caregiver Tips</h3>
        <ul>
            <li>Be on time for every session</li>
            <li>Encourage learners</li>
            <li>Keep your profile updated</li>
            <li>Complete sessions to earn more</li>
        </ul>
    </div>
</div>

<div class="actions">
    <a href="caregiver_classes.php">📅 View Schedule</a>
    <a href="caregiver_payments.php">💳 View Payments</a>
</div>

<footer>
&copy; <?= date("Y") ?> Gesture Link. All rights reserved.
</footer>

</body>
</html>
