<?php
session_start();
include("config.php");

// Allow only caregiver
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'caregiver') {
    header("Location: login.php");
    exit();
}

$caregiverId   = $_SESSION['id'];
$caregiverName = $_SESSION['name'] ?? 'Caregiver';

// ============================
// FETCH ONLY THIS CAREGIVER'S CLASSES
// ============================

$sql = "
SELECT 
    a.id AS application_id,
    a.session_date,
    a.session_time,
    a.call_status,
    a.call_room,
    u.name AS applicant_name,
    u.role AS applicant_role
FROM applications a
LEFT JOIN users u 
     ON a.user_id = u.id
WHERE a.assigned_status = 1
  AND a.assigned_caregiver_id = $caregiverId
ORDER BY a.session_date, a.session_time
";

$result = mysqli_query($conn, $sql);
if(!$result){
    die('SQL Error: '.mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Classes – Gesture Link</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
body{
    font-family:'Poppins',sans-serif;
    background:#0a0a23;
    color:white;
}
.wrapper{
    max-width:900px;
    margin:auto;
    padding:30px;
}
header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    background:#061429;
    padding:20px 30px;
    border-radius:12px;
}
.back-btn{
    background:#0044ff;
    padding:10px 20px;
    border-radius:25px;
    color:white;
    text-decoration:none;
}
table{
    width:100%;
    margin-top:30px;
    border-collapse:collapse;
}
th,td{
    padding:14px;
    text-align:center;
}
th{
    background:#0044ff;
}
tr:nth-child(even){
    background:rgba(255,255,255,0.05);
}
.empty{
    text-align:center;
    padding:30px;
    color:#ffd740;
}
.btn-success{
    background-color: #28a745;
    color: white;
    padding: 8px 12px;
    border-radius: 6px;
    text-decoration: none;
    font-size: 14px;
    border: none;
    cursor: pointer;
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>
<div class="wrapper">

<header>
    <h2>Welcome, <?php echo htmlspecialchars($caregiverName); ?></h2>
    <a href="caregiver_home.php" class="back-btn">← Back</a>
</header>

<h3 style="margin-top:30px;">📅 Approved Classes</h3>

<table>
<tr>
    <th>Applicant</th>
    <th>Role</th>
    <th>Date</th>
    <th>Time</th>
    <th>Action</th>
</tr>

<?php 
if(mysqli_num_rows($result) > 0): 
    while($row = mysqli_fetch_assoc($result)):
        $applicant_name = !empty($row['applicant_name']) ? $row['applicant_name'] : 'Unknown';
        $applicant_role = !empty($row['applicant_role']) ? ucfirst($row['applicant_role']) : 'Unknown';
        $application_id = $row['application_id'];
        $call_status   = $row['call_status'];
        $call_room     = $row['call_room'];
?>
    <tr>
        <td><?php echo htmlspecialchars($applicant_name); ?></td>
        <td><?php echo htmlspecialchars($applicant_role); ?></td>
        <td><?php echo !empty($row['session_date']) ? $row['session_date'] : '—'; ?></td>
        <td><?php echo !empty($row['session_time']) ? $row['session_time'] : '—'; ?></td>
        <td>
            <?php if($call_status == 'started' && !empty($call_room)): ?>
                <a href="<?= htmlspecialchars($call_room) ?>" target="_blank" class="btn-success">Join Call</a>
            <?php else: ?>
                <form action="caregiver_start_call.php" method="POST" style="margin:0;">
                    <input type="hidden" name="application_id" value="<?= $application_id ?>">
                    <button type="submit" class="btn-success">Start Call</button>
                </form>
            <?php endif; ?>
        </td>
    </tr>
<?php 
    endwhile; 
else: 
?>
    <tr>
        <td colspan="5" class="empty">No approved classes yet.</td>
    </tr>
<?php endif; ?>

</table>

</div>
</body>
</html>
