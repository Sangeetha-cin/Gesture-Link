<?php
session_start();

// Allow only session role
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'session') {
    header("Location: login.php");
    exit();
}

// Safe session name
$sessionName = $_SESSION['name'] ?? 'Session User';
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Session Home – Gesture Link</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

<style>
* { box-sizing: border-box; }

body, html {
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #0a0a23, #050515);
    color: white;
}

/* ===== NAVBAR ===== */
.navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 18px 40px;
    background: #061429;
    box-shadow: 0 4px 15px rgba(0,0,0,0.5);
}
.logo {
    font-size: 22px;
    font-weight: 700;
}
.navbar ul {
    list-style: none;
    display: flex;
    gap: 30px;
    margin: 0;
    padding: 0;
}
.navbar ul li a {
    text-decoration: none;
    color: #dcdcff;
    font-weight: 500;
}
.navbar ul li a:hover {
    color: #4d7cff;
}

/* ===== WRAPPER ===== */
.wrapper {
    padding: 40px;
    max-width: 1150px;
    margin: auto;
}

/* ===== HEADER ===== */
header {
    background: rgba(255,255,255,0.05);
    padding: 35px;
    border-radius: 15px;
    text-align: center;
    box-shadow: 0 0 25px rgba(0,68,255,0.15);
}
header h1 {
    margin: 0;
    font-size: 32px;
}
header p {
    margin-top: 10px;
    opacity: 0.9;
}

/* ===== CARDS ===== */
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 25px;
    margin-top: 45px;
}
.card {
    background: rgba(255,255,255,0.06);
    padding: 30px;
    border-radius: 15px;
    text-align: center;
    transition: 0.3s;
}
.card:hover {
    transform: translateY(-8px);
    box-shadow: 0 10px 30px rgba(0,68,255,0.25);
}
.card h3 {
    margin-bottom: 10px;
}
.card p {
    font-size: 14px;
    opacity: 0.85;
}
.card a {
    display: inline-block;
    margin-top: 18px;
    padding: 11px 22px;
    background: #0044ff;
    color: white;
    text-decoration: none;
    border-radius: 10px;
    font-weight: 600;
}
.card a:hover {
    background: #0033cc;
}

/* ===== DETAILS ===== */
.details {
    margin-top: 60px;
    background: rgba(255,255,255,0.04);
    padding: 35px;
    border-radius: 15px;
}
.details ul {
    line-height: 2;
    opacity: 0.9;
}

/* ===== STATS ===== */
.stats {
    margin-top: 50px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 25px;
}
.stat-box {
    background: rgba(255,255,255,0.05);
    padding: 30px;
    border-radius: 15px;
    text-align: center;
}
.stat-box h2 {
    font-size: 34px;
    color: #4d7cff;
    margin: 0;
}
.stat-box p {
    margin-top: 8px;
    opacity: 0.8;
}

/* ===== INFO BANNER ===== */
.info {
    margin-top: 60px;
    padding: 35px;
    border-radius: 15px;
    background: linear-gradient(135deg, #0033cc, #001f66);
    text-align: center;
}
.info h2 {
    margin-bottom: 10px;
}
.info p {
    opacity: 0.9;
}

/* ===== FOOTER ===== */
.footer {
    margin-top: 60px;
    text-align: center;
    font-size: 13px;
    opacity: 0.6;
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar">
    <div class="logo">Gesture Link</div>
    <ul>
        <li><a href="session_home.php">HOME</a></li>
        <li><a href="session_op.php">MANAGE</a></li>
        <li><a href="session_matching.php">ALLOCATION PANEL</a></li>
         <li><a href="managepay.php">PAYMENTS</a></li>
        <li><a href="logout.php">LOG OUT</a></li>
    </ul>
</nav>

<div class="wrapper">

<header>
    <h1>Welcome, <?php echo htmlspecialchars($sessionName); ?></h1>
    <p>Session Coordinator Dashboard</p>
</header>

<!-- MAIN CARDS -->
<div class="cards">
    <div class="card">
        <h3>Live Sessions</h3>
        <p>Monitor and organize upcoming live sessions.</p>
        <a href="#">View Sessions</a>
    </div>
    <div class="card">
        <h3>Participants</h3>
        <p>View learners registered for sessions.</p>
        <a href="#">View Learners</a>
    </div>
    <div class="card">
        <h3>Profile</h3>
        <p>Manage your profile and account settings.</p>
        <a href="#">My Profile</a>
    </div>
</div>

<!-- RESPONSIBILITIES -->
<div class="details">
    <h2>Session Responsibilities</h2>
    <ul>
        <li>Schedule and coordinate live learning sessions.</li>
        <li>Ensure smooth interaction between learners and caregivers.</li>
        <li>Track session completion and attendance.</li>
        <li>Handle session-related issues and updates.</li>
    </ul>
</div>

<!-- STATS -->
<div class="stats">
    <div class="stat-box">
        <h2>12</h2>
        <p>Upcoming Sessions</p>
    </div>
    <div class="stat-box">
        <h2>48</h2>
        <p>Active Learners</p>
    </div>
    <div class="stat-box">
        <h2>5</h2>
        <p>Pending Requests</p>
    </div>
</div>

<!-- INFO -->
<div class="info">
    <h2>Gesture Link Platform</h2>
    <p>
        Gesture Link helps bridge communication gaps by enabling
        structured, accessible, and interactive learning sessions.
    </p>
</div>

<div class="footer">
    © <?php echo date("Y"); ?> Gesture Link. All rights reserved.
</div>

</div>
</body>
</html>
