<?php
session_start();
$error = "";

// DB Connection
$conn = new mysqli("localhost", "root", "", "gesturelink");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST["email"]);
    $password = trim($_POST["password"]);

    if(empty($email) || empty($password)){
        $error = "Please fill in all required fields.";
    } else {

        $sql = "SELECT * FROM users WHERE email=? LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();

            if (password_verify($password, $row["password"])) {

                if($row['role'] != 'admin' && $row['status'] != 'accepted'){
                    $error = "Your account is pending approval.";
                } else {

                    $conn->query("UPDATE users SET login_count = login_count + 1 WHERE id = ".$row['id']);

                    $_SESSION['id'] = $row['id'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['fullname'] = $row['name'];
                    $_SESSION['role'] = $row['role'];

                    switch ($row['role']) {
                        case "admin": header("Location: adminhome.php"); exit();
                        case "user": header("Location: user_home.php"); exit();
                        case "learner": header("Location: learner_home.php"); exit();
                        case "interpreter": header("Location: interpreter_home.php"); exit();
                        case "caregiver": header("Location: caregiver_home.php"); exit();
                        case "session": header("Location: session_home.php"); exit();
                        default: $error = "Invalid user role.";
                    }
                }

            } else {
                $error = "Incorrect password.";
            }

        } else {
            $error = "No account found with this email.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | GestureLink</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#0f2027,#203a43,#ffff);;
    overflow:hidden;
}

/* MAIN WRAPPER */
.wrapper{
    width:100%;
    max-width:1200px;
    display:flex;
    background:rgba(255,255,255,0.08);
    backdrop-filter:blur(20px);
    border-radius:25px;
    box-shadow:0 30px 60px rgba(0,0,0,0.4);
    overflow:hidden;
}

/* LEFT SIDE */
.left{
    flex:1;
    padding:60px;
    color:white;
    display:flex;
    flex-direction:column;
    justify-content:center;
    position:relative;
}

.left h1{
    font-size:42px;
    font-weight:700;
    margin-bottom:20px;
}

.left p{
    font-size:16px;
    line-height:1.7;
    opacity:0.9;
}

/* Animated Gesture Icon */
.gesture-icon{
    font-size:150px;
    color:rgba(255,255,255,0.2);
    position:absolute;
    right:30px;
    bottom:30px;
    animation:float 4s ease-in-out infinite;
}

@keyframes float{
    0%{transform:translateY(0);}
    50%{transform:translateY(-20px);}
    100%{transform:translateY(0);}
}

/* RIGHT SIDE */
.right{
    flex:1;
    background:white;
    padding:60px 50px;
}

.right h2{
    text-align:center;
    margin-bottom:30px;
    font-weight:600;
    color:#2c5364;
}

/* INPUT STYLE */
.input-group{
    position:relative;
    margin-bottom:20px;
}

.input-group input{
    width:100%;
    padding:14px 45px 14px 15px;
    border-radius:12px;
    border:1px solid #ddd;
    font-size:15px;
    transition:0.3s;
}

.input-group input:focus{
    border-color:#2c5364;
    outline:none;
    box-shadow:0 0 0 3px rgba(44,83,100,0.1);
}

.input-group i{
    position:absolute;
    right:15px;
    top:50%;
    transform:translateY(-50%);
    color:#777;
}

/* BUTTON */
button{
    width:100%;
    padding:14px;
    border:none;
    border-radius:12px;
    background:linear-gradient(135deg,#2c5364,#203a43);
    color:white;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    transform:translateY(-3px);
    box-shadow:0 15px 30px rgba(0,0,0,0.2);
}

/* LINKS */
.links{
    text-align:center;
    margin-top:15px;
}

.links a{
    display:block;
    margin-top:8px;
    font-size:14px;
    color:#2c5364;
    text-decoration:none;
}

.links a:hover{
    text-decoration:underline;
}

/* ERROR */
.error{
    background:#ff4d4d;
    color:white;
    padding:10px;
    border-radius:8px;
    margin-bottom:15px;
    text-align:center;
    font-size:14px;
}

@media(max-width:950px){
    .wrapper{
        flex-direction:column;
    }
    .left{
        display:none;
    }
}
</style>
<script src="js/smart-voice-system.js"></script>
</head>

<body>

<div class="wrapper">

<!-- LEFT CONTENT -->
<div class="left">
    <h1>GestureLink</h1>
    <p>
        Bridging communication gaps through intelligent gesture recognition.
        Securely access your personalized dashboard and continue your
        seamless learning and communication experience.
    </p>

    <i class="fa-solid fa-hands gesture-icon"></i>
</div>

<!-- RIGHT LOGIN FORM -->
<div class="right">
    <h2>Login In</h2>

    <?php if($error != "") echo "<div class='error'>$error</div>"; ?>

    <form method="POST">

        <div class="input-group">
            <input type="email" name="email" placeholder="Email Address" required>
            <i class="fa-solid fa-envelope"></i>
        </div>

        <div class="input-group">
            <input type="password" id="password" name="password" placeholder="Password" required>
            <i class="fa-solid fa-eye" onclick="togglePassword()" style="cursor:pointer;"></i>
        </div>

        <button type="submit">Login to Account</button>

        <div class="links">
            <a href="register.php">Create New Account</a>
            <a href="index.php">Back to Home</a>
        </div>

    </form>
</div>

</div>

<script>
function togglePassword(){
    var pass = document.getElementById("password");
    if(pass.type === "password"){
        pass.type = "text";
    } else {
        pass.type = "password";
    }
}
</script>

</body>
</html>