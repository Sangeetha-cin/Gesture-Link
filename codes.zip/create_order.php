<?php
require('config.php'); // database if needed

$key_id = "YOUR_TEST_KEY_ID";
$key_secret = "YOUR_TEST_KEY_SECRET";

$amount = 50000; // ₹500 (because smallest unit)

$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, "https://api.razorpay.com/v1/orders");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);

curl_setopt($ch, CURLOPT_USERPWD, $key_id . ":" . $key_secret);

$data = array(
    "amount" => $amount,
    "currency" => "INR",
    "receipt" => "order_rcptid_11"
);

curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

$result = curl_exec($ch);
echo $result;
?>