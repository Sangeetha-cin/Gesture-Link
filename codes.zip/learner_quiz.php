<?php
session_start();
include("config.php");

if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'learner') {
    header("Location: login.php");
    exit();
}

$learnerId = $_SESSION['id'];

/* ================= NEXT LEVEL ================= */
if (isset($_POST['next'])) {
    $_SESSION['level'] = $_SESSION['level'] + 1;
    $_SESSION['qno']   = 0;
    $_SESSION['score'] = 0;
    header("Location: learner_quiz.php");
    exit();
}

/* ================= INITIALIZE ================= */
if (!isset($_SESSION['level'])) {

    $res = mysqli_query($conn,
        "SELECT MAX(level) AS max_level
         FROM learner_progress
         WHERE learner_id='$learnerId'"
    );
    $row = mysqli_fetch_assoc($res);

    $_SESSION['level'] = ($row['max_level']) ? ($row['max_level'] + 1) : 1;
    $_SESSION['qno']   = 0;
    $_SESSION['score'] = 0;
}

$level = $_SESSION['level'];
$qno   = $_SESSION['qno'];
$score = $_SESSION['score'];

/* ================= FETCH QUESTIONS ================= */
$qRes = mysqli_query($conn,
    "SELECT * FROM quiz_questions WHERE level='$level' ORDER BY id ASC"
);
$totalQ   = mysqli_num_rows($qRes);
$questions = mysqli_fetch_all($qRes, MYSQLI_ASSOC);

/* ================= HANDLE ANSWER ================= */
if (isset($_POST['answer'])) {

    if ($_POST['answer'] == $questions[$qno]['correct_option']) {
        $_SESSION['score']++;
    }

    $_SESSION['qno']++;
    header("Location: learner_quiz.php");
    exit();
}

/* ================= LEVEL COMPLETED ================= */
if ($qno >= $totalQ && $totalQ > 0) {

    mysqli_query($conn,
        "DELETE FROM learner_progress
         WHERE learner_id='$learnerId' AND level='$level'"
    );

    mysqli_query($conn,
        "INSERT INTO learner_progress (learner_id, level, score)
         VALUES ('$learnerId','$level','$score')"
    );

    $percentage = round(($score / $totalQ) * 100);
    $deg = $percentage * 3.6;
    $nextLevel = $level + 1;
?>
<!DOCTYPE html>
<html>
<head>
<title>Level Completed</title>
<style>
body{
    margin:0;
    font-family:'Segoe UI',sans-serif;
    background:#f4f6fb;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}
.card{
    background:#fff;
    padding:40px;
    border-radius:16px;
    width:380px;
    text-align:center;
    box-shadow:0 20px 40px rgba(0,0,0,0.15);
}
.ring{
    width:150px;height:150px;border-radius:50%;
    background:conic-gradient(#0b1f3a <?= $deg ?>deg,#e5e7eb 0deg);
    display:flex;align-items:center;justify-content:center;
    margin:0 auto 20px;
}
.ring::before{
    content:"";
    width:110px;height:110px;
    background:#fff;border-radius:50%;
    position:absolute;
}
.percent{
    position:relative;
    font-size:22px;
    font-weight:bold;
    color:#0b1f3a;
}
button{
    margin-top:20px;
    padding:12px 22px;
    border:none;
    background:#0b1f3a;
    color:#fff;
    border-radius:8px;
    cursor:pointer;
}
</style>
</head>
<body>
<div class="card">
<h2>Level <?= $level ?> Completed 🎉</h2>

<div class="ring">
<div class="percent"><?= $percentage ?>%</div>
</div>

<p><strong>Score:</strong> <?= $score ?> / <?= $totalQ ?></p>

<form method="post">
<button name="next">Next Level</button>
</form>
</div>
</body>
</html>
<?php
exit();
}
/* ================= END LEVEL COMPLETED ================= */


/* ================= NO QUESTIONS ================= */
if ($totalQ == 0) {
?>
<!DOCTYPE html>
<html>
<head>
<title>No More Levels</title>
</head>
<body style="font-family:Segoe UI;text-align:center;margin-top:100px;">
<h2>No More Levels Available</h2>
<a href="learner_home.php">Back to Home</a>
</body>
</html>
<?php
exit();
}
/* ================= END NO QUESTIONS ================= */


/* ================= CURRENT QUESTION ================= */
$q = $questions[$qno];
$ext = strtolower(pathinfo($q['question'], PATHINFO_EXTENSION));
$progressPercent = round((($qno) / $totalQ) * 100);
?>

<!DOCTYPE html>
<html>
<head>
<title>Learner Quiz</title>
<style>
body{margin:0;font-family:'Segoe UI',sans-serif;background:#f4f6fb;}
.topbar{
background:#0b1f3a;color:white;padding:15px 30px;
display:flex;justify-content:space-between;align-items:center;
}
.back-btn{
background:white;color:#0b1f3a;padding:6px 14px;
border-radius:6px;text-decoration:none;font-size:13px;font-weight:600;
}
.main{display:flex;max-width:1100px;margin:40px auto;gap:30px;}
.sidebar{
width:260px;background:white;border-radius:14px;
padding:25px;box-shadow:0 10px 25px rgba(0,0,0,0.08);
}
.quiz-card{
flex:1;background:white;padding:30px;border-radius:16px;
box-shadow:0 15px 35px rgba(0,0,0,0.1);
}
video,audio{width:100%;max-height:240px;border-radius:10px;margin-bottom:20px;}
.option{margin:12px 0;}
.option label{
display:block;padding:12px;border:1px solid #d1d9e6;
border-radius:8px;cursor:pointer;font-size:14px;
}
button{
width:100%;margin-top:20px;padding:13px;border:none;
background:#0b1f3a;color:white;border-radius:8px;
}
.progress{
width:100%;height:8px;background:#e0e7ff;
border-radius:10px;overflow:hidden;margin-top:8px;
}
.progress-bar{
height:8px;background:#0b1f3a;
width:<?= $progressPercent ?>%;
}
</style>
</head>
<body>

<div class="topbar">
<a href="learner_home.php" class="back-btn">⬅ Back</a>
<div>Level <?= $level ?> | Question <?= $qno+1 ?> of <?= $totalQ ?></div>
</div>

<div class="main">

<div class="sidebar">
<h3>Quiz Overview</h3>
<p><strong>Level:</strong> <?= $level ?></p>
<p><strong>Score:</strong> <?= $score ?></p>
<p><strong>Progress:</strong> <?= $progressPercent ?>%</p>
<div class="progress">
<div class="progress-bar"></div>
</div>
</div>

<div class="quiz-card">

<?php if (in_array($ext, ['mp4','webm','ogg'])) { ?>
<video controls>
<source src="video.php?file=<?= urlencode($q['question']) ?>">
</video>
<?php } else { ?>
<audio controls>
<source src="video.php?file=<?= urlencode($q['question']) ?>">
</audio>
<?php } ?>

<form method="post">
<?php for($i=1;$i<=4;$i++){ ?>
<div class="option">
<label>
<input type="radio" name="answer" value="<?= $i ?>" required>
<?= $q["option$i"] ?>
</label>
</div>
<?php } ?>
<button>Submit Answer</button>
</form>

</div>
</div>
</body>
</html>